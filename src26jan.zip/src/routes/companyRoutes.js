
import express from 'express';
import {
    sendCompanyOtp,
    registerCompany,
    getCompaniesDropdown,
    getVerifiedCompaniesCount,
    getPendingCompaniesCount,
    getAllCompanies,
    getAgentRequests,
    approveAgentRequest,
    rejectAgentRequest,
    getCompanyAgents,
    getDashboardStats
} from '../controllers/companyController.js';
import { approveCompany, rejectCompany } from '../controllers/adminController.js';
import { protect, authorize } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

const router = express.Router();

router.post('/register/send-otp', sendCompanyOtp);
router.post('/register', upload.array('documents'), registerCompany);
router.get('/dropdown', getCompaniesDropdown);

// Statistics (Protected)
router.get('/statistics/verified', protect, getVerifiedCompaniesCount);
router.get('/statistics/pending', protect, getPendingCompaniesCount);
router.get('/statistics/dashboard', protect, authorize('company', 'company_agent'), getDashboardStats);

// Admin Routes
router.get('/', protect, authorize('admin'), getAllCompanies);

// Company Agent Management Routes
router.get('/agents', protect, authorize('company'), getCompanyAgents);
router.get('/agent-requests', protect, authorize('company'), getAgentRequests);
router.post('/agent-requests/:id/approve', protect, authorize('company'), approveAgentRequest);
router.post('/agent-requests/:id/reject', protect, authorize('company'), rejectAgentRequest);

// Aliases for Admin Action from Frontend (AdminContext calls these)
// Requires Admin Auth
router.post('/:id/approve', protect, authorize('admin'), approveCompany);
router.post('/:id/reject', protect, authorize('admin'), rejectCompany);

export default router;
