import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Document = sequelize.define('Document', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    // ID of the entity this document belongs to (User ID, Property ID, etc.)
    entityId: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    // Type of entity
    entityType: {
        type: DataTypes.ENUM('USER', 'COMPANY', 'AGENT', 'PROPERTY', 'PROJECT'),
        allowNull: false
    },
    // Type of document (e.g., 'license', 'id_proof', 'brochure')
    documentType: {
        type: DataTypes.STRING,
        allowNull: true
    },
    fileName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    fileUrl: {
        type: DataTypes.STRING,
        allowNull: false // URL or path
    },
    mimeType: {
        type: DataTypes.STRING,
        allowNull: true
    },
    fileSize: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    status: {
        type: DataTypes.ENUM('PENDING', 'VERIFIED', 'REJECTED'),
        defaultValue: 'PENDING'
    }
}, {
    timestamps: true
});

export default Document;
