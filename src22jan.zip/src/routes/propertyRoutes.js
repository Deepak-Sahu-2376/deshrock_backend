import express from 'express';
import {
    getProjects,
    getAdminProjects,
    getCompanyProjects,
    getAdminPendingProjects,
    getPendingProperties,
    approveProperty,
    rejectProperty,
    approveProject,
    rejectProject,
    getCompanyPendingProperties,
    approveCompanyProperty,
    rejectCompanyProperty,
    createProperty,
    getCompanyProperties,
    getAgentProperties,
    createPhase
} from '../controllers/propertyController.js';
import { createProject, getProjectById } from '../controllers/projectController.js';
import { protect, authorize } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

const router = express.Router();

// Routes mounted at /api/v1/properties

// Create Property
router.post('/create', protect, upload.fields([
    { name: 'images', maxCount: 10 },
    { name: 'floorPlan', maxCount: 1 },
    { name: 'video', maxCount: 1 }
]), createProperty);


// Projects
router.get('/projects', getProjects); // /api/v1/properties/projects

// Create Project (Matches frontend: /api/v1/properties/projects/create)
router.post('/projects/create', protect, upload.fields([
    { name: 'mediaFiles', maxCount: 50 },
    { name: 'thumbnail', maxCount: 1 },
    { name: 'brochure', maxCount: 1 }
]), createProject);

// Company Projects View
router.get('/projects/view/my-company', protect, authorize('company', 'company_agent'), getCompanyProjects);

// Company Properties (All - My Properties)
router.get('/company/all', protect, authorize('company', 'company_agent'), getCompanyProperties);

// Agent Properties (My Properties)
router.get('/agent/:id', protect, authorize('agent', 'company', 'admin', 'company_agent'), getAgentProperties);

// Company Pending Properties (For Company Admin)
router.get('/company/pending', protect, authorize('company'), getCompanyPendingProperties);

// Company Property Approval
router.post('/:id/company-approve', protect, authorize('company'), approveCompanyProperty);
router.post('/:id/company-reject', protect, authorize('company'), rejectCompanyProperty);

// Admin Pending Projects
router.get('/projects/pending', protect, authorize('admin'), getAdminPendingProjects);

// Pending Verification
router.get('/pending-verification', getPendingProperties);

// Approve/Reject Property
router.post('/:id/approve', approveProperty);
router.post('/:id/reject', rejectProperty);

// Projects (Matches frontend url: /api/v1/properties/projects/...)
router.get('/projects/view', protect, authorize('admin'), getAdminProjects); // Admin View
router.post('/projects/view/:projectId/approve', approveProject);
router.post('/projects/view/:projectId/reject', rejectProject);

// Get Single Project by ID
router.get('/projects/:id', getProjectById);

// Create Phase - MOVED to projectRoutes.js
// router.post('/projects/:projectId/phases', createPhase);

export default router;
