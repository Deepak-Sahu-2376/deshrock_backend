import express from 'express';
import { protect } from '../middlewares/authMiddleware.js';
import {
    scheduleVisit,
    getMyVisits,
    getAgentTodayVisits,
    getAgentUpcomingVisits,
    updateVisitStatus,
    cancelVisitByUser,
    getAgentPendingVisits,
    confirmVisit,
    completeVisit,
    cancelVisitByAgent,
    getAgentConfirmedVisits,
    getOwnerVisits
} from '../controllers/visitController.js';

const router = express.Router();

router.use(protect);

// Buyer Routes
router.post('/', scheduleVisit);
router.get('/myVisits', getMyVisits); // Matches /api/v1/visits/myVisits
router.get('/received', getOwnerVisits);

// Agent Routes
router.get('/agent/visits/today', getAgentTodayVisits); // Matches /api/v1/visit/agent...
router.get('/agent/visits/upcoming', getAgentUpcomingVisits);
router.get('/agent/pending', getAgentPendingVisits);
router.get('/agent/confirmed', getAgentConfirmedVisits);

// Agent Actions
router.patch('/:id/confirm', confirmVisit);
router.patch('/:id/complete', completeVisit);
router.patch('/:id/cancel', cancelVisitByAgent);

// Shared/Update
router.put('/:id/status', updateVisitStatus);
router.patch('/:id/cancel-by-user', cancelVisitByUser);

export default router;
