import express from 'express';
import { createPhase, getProjects } from '../controllers/propertyController.js';
import { protect, authorize } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

const router = express.Router();

// /api/v1/projects

router.get('/', getProjects); // If frontend calls /api/v1/projects directly

// Create Phase
router.post('/:projectId/phases', protect, authorize('admin', 'company', 'company_agent'), upload.fields([
    { name: 'logoFile', maxCount: 1 },
    { name: 'brochureFile', maxCount: 1 },
    { name: 'masterPlanFile', maxCount: 1 },
    { name: 'floorPlanFiles', maxCount: 10 }
]), createPhase);

export default router;
