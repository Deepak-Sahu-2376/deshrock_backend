
import db from '../models/index.js';

const updateEnum = async () => {
    try {
        await db.sequelize.authenticate();
        console.log('Database connected.');

        // Attempt to add 'PENDING_COMPANY' to the enum type
        // This command is Postgres specific.
        try {
            await db.sequelize.query("ALTER TYPE \"enum_Properties_status\" ADD VALUE 'PENDING_COMPANY';");
            console.log("Added PENDING_COMPANY to enum.");
        } catch (e) {
            console.log("PENDING_COMPANY likely already exists or error:", e.message);
        }

        process.exit(0);
    } catch (error) {
        console.error('Error updating enum:', error);
        process.exit(1);
    }
};

updateEnum();
