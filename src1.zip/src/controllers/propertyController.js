import { Op } from 'sequelize';
import db from '../models/index.js';
import Phase from '../models/Phase.js';
import { sendTemplateEmail } from '../services/emailService.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// @desc    Get all projects
// @route   GET /api/v1/projects OR /api/v1/properties/projects
const getProjects = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        const where = {
            isActive: true,
            approvalStatus: 'APPROVED'
        };

        if (req.query.city) {
            where.city = { [Op.iLike]: req.query.city };
        }

        const { count, rows } = await db.Project.findAndCountAll({
            offset,
            limit: size,
            where,
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id']
            }]
        });

        // Transform data to match frontend expectations
        const projects = rows.map(p => {
            const project = p.toJSON();
            // Map media to mediaFiles and url to mediaUrl
            project.mediaFiles = (project.media || []).map(m => ({
                ...m,
                mediaUrl: m.url
            }));
            return project;
        });

        res.status(200).json({
            success: true,
            content: projects,
            data: {
                content: projects,
                projects: projects, // For compatibility if frontend expects this
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        console.error('Error fetching projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get all projects (Admin - includes inactive)
// @route   GET /api/v1/properties/projects/view
const getAdminProjects = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        const { count, rows } = await db.Project.findAndCountAll({
            offset,
            limit: size,
            where: { approvalStatus: 'APPROVED' },
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id']
            }]
        });

        // Transform data to match frontend expectations
        const projects = rows.map(p => {
            const project = p.toJSON();
            project.mediaFiles = (project.media || []).map(m => ({
                ...m,
                mediaUrl: m.url
            }));
            return project;
        });

        res.status(200).json({
            success: true,
            content: projects,
            data: {
                content: projects,
                projects: projects,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        console.error('Error fetching admin projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Featured Properties
// @route   GET /api/v1/public/properties/featured
const getFeaturedProperties = async (req, res) => {
    try {
        const properties = await db.Property.findAll({
            where: {
                isFeatured: true,
                status: 'APPROVED'
            },
            limit: 6,
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName']
            }]
        });

        res.status(200).json({
            success: true,
            content: properties,
            data: {
                content: properties
            }
        });
    } catch (error) {
        console.error('Error fetching featured properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Top Featured Properties
// @route   GET /api/v1/public/properties/featured/top
const getFeaturedPropertiesTop = async (req, res) => {
    try {
        const properties = await db.Property.findAll({
            where: {
                isFeatured: true,
                status: 'APPROVED'
            },
            limit: 3,
            order: [['viewCount', 'DESC']], // Assuming top means most viewed or just latest
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName']
            }]
        });

        res.status(200).json({
            success: true,
            data: properties
        });
    } catch (error) {
        console.error('Error fetching top properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get All Public Properties
// @route   GET /api/v1/public/properties
const getProperties = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 12;
        const offset = page * size;

        // Basic filtering support can be added here (e.g. req.query.type)
        const where = { status: 'APPROVED' };
        if (req.query.propertyType) where.propertyType = req.query.propertyType;
        if (req.query.listingType) where.listingType = req.query.listingType;
        if (req.query.city) where.city = { [Op.iLike]: req.query.city };

        const { count, rows } = await db.Property.findAndCountAll({
            where,
            offset,
            limit: size,
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName']
            }, {
                model: db.User,
                as: 'user',
                attributes: ['firstName', 'lastName', 'email']
            }]
        });

        res.status(200).json({
            success: true,
            content: rows,
            data: {
                content: rows,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        console.error('Error fetching properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Pending Properties (Admin)
// @route   GET /api/v1/properties/pending-verification
const getPendingProperties = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        const { count, rows } = await db.Property.findAndCountAll({
            where: { status: 'PENDING' },
            offset,
            limit: size,
            order: [['createdAt', 'ASC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id']
            }, {
                model: db.User,
                as: 'user',
                attributes: ['firstName', 'lastName', 'email']
            }]
        });

        res.status(200).json({
            success: true,
            content: rows,
            data: {
                content: rows,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        console.error('Error fetching pending properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Pending Projects (Admin)
// @route   GET /api/v1/properties/projects/pending
const getAdminPendingProjects = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        const { count, rows } = await db.Project.findAndCountAll({
            where: { approvalStatus: 'PENDING' },
            offset,
            limit: size,
            order: [['createdAt', 'ASC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id']
            }]
        });

        // Transform data
        const projects = rows.map(p => {
            const project = p.toJSON();
            project.mediaFiles = (project.media || []).map(m => ({
                ...m,
                mediaUrl: m.url
            }));
            return project;
        });

        res.status(200).json({
            success: true,
            data: {
                projects: projects,
                content: projects,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        console.error('Error fetching pending projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Property
// @route   POST /api/v1/properties/:id/approve
const approveProperty = async (req, res) => {
    try {
        const property = await db.Property.findByPk(req.params.id, {
            include: [
                { model: db.User, as: 'user' },
                { model: db.CompanyProfile, as: 'company' }
            ]
        });
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        property.status = 'APPROVED';
        await property.save();

        // Send Email
        const recipient = property.user || (property.company && property.company.asUser ? property.company.asUser : null);
        // Note: CompanyProfile maps to User via userId. We should probably fetch User of the company if property.user is null (which happens for company listings sometimes if userId isn't set? No, Property has userId).
        // Let's rely on property.user (creator).

        if (property.user) {
            const listData = {
                userName: property.user.firstName,
                propertyTitle: property.title,
                propertyId: property.id,
                location: property.city,
                propertyType: property.propertyType,
                price: property.basePrice,
                viewLink: `${process.env.CLIENT_URL}/property/${property.id}`
            };
            sendTemplateEmail(property.user.email, 'PROPERTY_LISTED', listData).catch(console.error);
        }

        res.status(200).json({ success: true, message: 'Property approved successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Property
// @route   POST /api/v1/properties/:id/reject
const rejectProperty = async (req, res) => {
    try {
        const { reason } = req.body;
        const property = await db.Property.findByPk(req.params.id);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        property.status = 'REJECTED';
        property.rejectionReason = reason;
        await property.save();

        res.status(200).json({ success: true, message: 'Property rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Project
// @route   POST /api/v1/projects/view/:projectId/approve (Mapped in admin routes/property routes)
const approveProject = async (req, res) => {
    try {
        const { projectId } = req.params;
        const project = await db.Project.findByPk(projectId);

        if (!project) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }

        project.isActive = true;
        project.approvalStatus = 'APPROVED';
        await project.save();

        res.status(200).json({ success: true, message: 'Project approved' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Reject Project
// @route   POST /api/v1/projects/view/:projectId/reject
const rejectProject = async (req, res) => {
    try {
        const { projectId } = req.params;
        const project = await db.Project.findByPk(projectId);

        if (!project) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }

        project.isActive = false;
        project.approvalStatus = 'REJECTED';
        await project.save();

        res.status(200).json({ success: true, message: 'Project rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Create Project Phase
// @route   POST /api/v1/projects/:projectId/phases
const createPhase = async (req, res) => {
    try {
        const { projectId } = req.params;
        const project = await db.Project.findByPk(projectId);
        if (!project) {
            return res.status(404).json({ success: false, message: 'Project not found' });
        }

        // Handle FormData vs JSON
        let phaseData = req.body;
        if (req.body.phase) {
            try {
                phaseData = JSON.parse(req.body.phase);
            } catch (e) {
                return res.status(400).json({ success: false, message: 'Invalid phase data format' });
            }
        }

        // Process Files
        const files = req.files || {};
        const logoFile = files['logoFile'] ? files['logoFile'][0] : null;
        const brochureFile = files['brochureFile'] ? files['brochureFile'][0] : null;
        const masterPlanFile = files['masterPlanFile'] ? files['masterPlanFile'][0] : null;
        const floorPlanFiles = files['floorPlanFiles'] || [];

        // Map file paths
        const phaseLogoUrl = logoFile ? `/uploads/documents/${logoFile.filename}` : null;
        const phaseBrochureUrl = brochureFile ? `/uploads/documents/${brochureFile.filename}` : null;
        const masterPlanUrl = masterPlanFile ? `/uploads/documents/${masterPlanFile.filename}` : null;
        const floorPlanUrls = floorPlanFiles.map(f => `/uploads/documents/${f.filename}`);

        const newPhase = await Phase.create({
            ...phaseData,
            projectId: projectId,
            phaseLogoUrl,
            phaseBrochureUrl,
            masterPlanUrl,
            floorPlanUrls
        });

        res.status(201).json({
            success: true,
            message: "Phase created successfully",
            data: newPhase
        });
    } catch (error) {
        console.error('Error creating phase:', error);
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Create Property
// @route   POST /api/v1/properties/create
const createProperty = async (req, res) => {
    try {
        if (!req.body.property) {
            return res.status(400).json({ success: false, message: 'Property data is missing' });
        }

        const propertyData = JSON.parse(req.body.property);
        const files = req.files || {};

        const imageFiles = files['images'] || [];
        const floorPlanFile = files['floorPlan'] ? files['floorPlan'][0] : null;
        const videoFile = files['video'] ? files['video'][0] : null;

        // Generate URLs (assuming static serve setup at /uploads)
        // Using relative path so it works when served statically
        const imageUrls = imageFiles.map(file => `/uploads/documents/${file.filename}`);
        const floorPlanUrl = floorPlanFile ? `/uploads/documents/${floorPlanFile.filename}` : null;
        const videoUrl = videoFile ? `/uploads/documents/${videoFile.filename}` : null;

        // Check if user is a buyer and restrict to Rent only
        if (req.user.userType === 'buyer') {
            if (propertyData.listingType === 'SALE') {
                return res.status(403).json({ success: false, message: 'Buyers can only post properties for Rent.' });
            }
        }

        // Check if user is a company
        const companyProfile = await db.CompanyProfile.findOne({
            where: { userId: req.user.id }
        });

        // Determine companyId and Initial Status
        let companyId = null;
        let initialStatus = 'PENDING'; // Default for Company Admin

        if (req.user.userType === 'company_agent') {
            // For company agents, we need to find the company they belong to
            const agentProfile = await db.AgentProfile.findOne({ where: { userId: req.user.id } });
            if (!agentProfile) {
                return res.status(403).json({ success: false, message: 'Agent profile not found' });
            }
            companyId = agentProfile.companyId;
            initialStatus = 'PENDING_COMPANY';
        } else if (companyProfile) {
            // Company Admin creating property
            companyId = companyProfile.id;
            initialStatus = 'PENDING';
        } else if (req.user.userType === 'buyer') {
            // Buyers
            initialStatus = 'PENDING';
        } else {
            // Individual Agent
            initialStatus = 'PENDING';
        }

        const newProperty = await db.Property.create({
            ...propertyData,
            companyId: companyId,
            userId: req.user.id,
            images: imageUrls,
            floorPlan: floorPlanUrl,
            video: videoUrl,
            status: initialStatus
        });

        // Send Email
        const subData = {
            userName: req.user.firstName,
            propertyTitle: newProperty.title,
            location: newProperty.city || 'Location',
            submittedDate: new Date().toLocaleString()
        };
        sendTemplateEmail(req.user.email, 'PROPERTY_SUBMITTED', subData).catch(console.error);

        res.status(201).json({
            success: true,
            message: 'Property created successfully',
            data: newProperty
        });

    } catch (error) {
        console.error('Error creating property:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Property By ID (Public)
// @route   GET /api/v1/public/properties/:id
const getPropertyById = async (req, res) => {
    try {
        const property = await db.Property.findByPk(req.params.id, {
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id', 'website'],
                include: [{
                    model: db.User,
                    as: 'user',
                    attributes: ['email', 'phone']
                }]
            }]
        });

        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        if (property.status !== 'APPROVED') {
            // Allow access if user is admin or owner or company admin
            let isAuthorized = false;

            if (req.user) {
                if (req.user.userType === 'admin') {
                    isAuthorized = true;
                } else if (req.user.id === property.userId) {
                    isAuthorized = true;
                } else if (req.user.userType === 'company' && property.user?.companyId === req.user.companyId) {
                    // Need to load company association to verify this, but for now owner check + admin check is good start.
                    // The query already includes user, so check property.user.companyId?
                    // No, user include is tricky. property.user is the agent.
                    // If req.user is the company, check if property.user.companyId == req.user.id (if req.user is company type)
                    // or whatever relation.
                    // IMPORTANT: 'property' fetch above needs to include user to verify company ownership.
                    // The current fetch includes:
                    /*
                       include: [
                           { model: db.PropertyImage, as: 'images' },
                           { model: db.PropertyAmenity, as: 'amenities' },
                           { model: db.User, as: 'user', attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'avatar'] }
                       ]
                    */
                    // It does NOT include companyId on user attributes explicitly in getPropertyById?
                    // Let's check getPropertyById implementation.
                }

                // Simplified Check: Admin or Direct Owner
                if (req.user.userType === 'admin' || req.user.id === property.userId) {
                    isAuthorized = true;
                }
            }

            if (!isAuthorized) {
                return res.status(404).json({ success: false, message: 'Property not found' });
            }
        }

        property.viewCount = (property.viewCount || 0) + 1;
        await property.save({ hooks: false });

        res.status(200).json({
            success: true,
            data: property
        });
    } catch (error) {
        console.error('Error fetching property details:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Company Projects (My Projects)
// @route   GET /api/v1/properties/projects/view/my-company
const getCompanyProjects = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        // Find company profile for the user
        // If userType is 'company_agent', the companyId might be directly in user or linked differently
        // But for 'company' type, they have a CompanyProfile.
        // Assuming req.user is populated by protect middleware.

        let companyId;

        if (req.user.userType === 'company') {
            const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
            if (!company) {
                return res.status(404).json({ success: false, message: 'Company profile not found' });
            }
            companyId = company.id;
        } else if (req.user.userType === 'company_agent') {
            const agent = await db.AgentProfile.findOne({ where: { userId: req.user.id } });

            if (!agent) {
                return res.status(404).json({ success: false, message: 'Agent profile not found' });
            }

            companyId = agent.companyId;

            if (!companyId) {
                return res.status(403).json({ success: false, message: 'Company ID not found for agent' });
            }
        } else {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const { count, rows } = await db.Project.findAndCountAll({
            where: { companyId },
            offset,
            limit: size,
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id']
            }]
        });

        const projects = rows.map(p => {
            const project = p.toJSON();
            project.mediaFiles = (project.media || []).map(m => ({
                ...m,
                mediaUrl: m.url
            }));
            return project;
        });

        res.status(200).json({
            success: true,
            data: {
                projects: projects,
                content: projects,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });

    } catch (error) {
        console.error('Error fetching company projects:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Company Pending Properties (For Company Admin)
// @route   GET /api/v1/properties/company/pending
const getCompanyPendingProperties = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        // Get Company ID
        const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
        if (!company) {
            return res.status(404).json({ success: false, message: 'Company profile not found' });
        }

        const { count, rows } = await db.Property.findAndCountAll({
            where: {
                companyId: company.id,
                status: 'PENDING_COMPANY'
            },
            offset,
            limit: size,
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id']
            }, {
                model: db.User,
                as: 'user',
                attributes: ['id', 'firstName', 'lastName', 'email']
            }]
        });

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });

    } catch (error) {
        console.error('Error fetching pending company properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Company Property (Company Admin)
// @route   POST /api/v1/properties/:id/company-approve
const approveCompanyProperty = async (req, res) => {
    try {
        const property = await db.Property.findByPk(req.params.id);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Verify ownership (Company Admin can only approve their company's properties)
        const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
        if (!company || property.companyId !== company.id) {
            return res.status(403).json({ success: false, message: 'Not authorized to approve this property' });
        }

        if (property.status !== 'PENDING_COMPANY') {
            return res.status(400).json({ success: false, message: 'Property is not in pending company status' });
        }

        property.status = 'PENDING'; // Move to Admin Pending
        await property.save();

        res.status(200).json({ success: true, message: 'Property approved by company' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Company Property (Company Admin)
// @route   POST /api/v1/properties/:id/company-reject
const rejectCompanyProperty = async (req, res) => {
    try {
        const { reason } = req.body;
        const property = await db.Property.findByPk(req.params.id);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Verify ownership
        const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
        if (!company || property.companyId !== company.id) {
            return res.status(403).json({ success: false, message: 'Not authorized to reject this property' });
        }

        property.status = 'REJECTED'; // Or REJECTED_BY_COMPANY
        property.rejectionReason = reason;
        await property.save();

        res.status(200).json({ success: true, message: 'Property rejected by company' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get All Company Properties (My Properties)
// @route   GET /api/v1/properties/company/all
const getCompanyProperties = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;
        const status = req.query.status;

        // Determine Company ID
        let companyId;
        if (req.user.userType === 'company') {
            const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
            if (!company) return res.status(404).json({ success: false, message: 'Company profile not found' });
            companyId = company.id;
        } else if (req.user.userType === 'company_agent') {
            const agent = await db.AgentProfile.findOne({ where: { userId: req.user.id } });
            if (!agent) return res.status(404).json({ success: false, message: 'Agent profile not found' });
            companyId = agent.companyId;
        } else {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const where = { companyId };
        if (status) {
            where.status = status;
        }

        const { count, rows } = await db.Property.findAndCountAll({
            where,
            offset,
            limit: size,
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName']
            }, {
                model: db.User, // To see which agent posted it
                as: 'user',
                attributes: ['id', 'firstName', 'lastName', 'email']
            }]
        });

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });

    } catch (error) {
        console.error('Error fetching company properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Update Property (Admin/Owner)
// @route   PUT /api/v1/properties/:id
const updateProperty = async (req, res) => {
    try {
        const property = await db.Property.findByPk(req.params.id);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Authorization: Admin or Owner (User or Company Agent owning it)
        let isAuthorized = false;
        if (req.user.userType === 'admin') {
            isAuthorized = true;
        } else if (req.user.id === property.userId) {
            isAuthorized = true;
        } else if (req.user.userType === 'company_agent') {
            // Check if agent belongs to the company that owns the property
            const agent = await db.AgentProfile.findOne({ where: { userId: req.user.id } });
            if (agent && agent.companyId === property.companyId) {
                isAuthorized = true;
            }
        } else if (req.user.userType === 'company') {
            const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
            if (company && company.id === property.companyId) {
                isAuthorized = true;
            }
        }

        if (!isAuthorized) {
            return res.status(403).json({ success: false, message: 'Not authorized to update this property' });
        }

        // Handle Body Data
        // If multipart, data might be in req.body.property or direct fields depending on frontend.
        // Assuming similar to create: req.body.property JSON string if files involved, or direct body if JSON request.
        let updates = req.body;
        if (req.body.property) {
            try {
                updates = JSON.parse(req.body.property);
            } catch (e) {
                return res.status(400).json({ success: false, message: 'Invalid property data' });
            }
        }

        // Handle File Updates (Optional)
        // If files are provided, we append/replace. 
        // Logic: specific endpoints for adding images usually better, but for full update:
        // If new images provided, Append? Or Replace?
        // Let's assume Append for now or separate logic.
        // For simplicity in this step, let's handle text fields update. Media handling usually needs careful UI logic (delete specific image, add new).

        // Update fields
        const allowedFields = ['title', 'description', 'price', 'basePrice', 'city', 'address', 'latitude', 'longitude', 'propertyType', 'listingType', 'bedrooms', 'bathrooms', 'area', 'status']; // Admin can update status too?

        // Only Admin can update Status directly via Update? Or keep validation workflow?
        // Let's allow Admin to update generic fields.

        Object.keys(updates).forEach(key => {
            if (allowedFields.includes(key)) {
                property[key] = updates[key];
            }
        });

        // Admin override status
        if (req.user.userType === 'admin' && updates.status) {
            property.status = updates.status;
        }

        // --- Media Handling ---
        let imagesChanged = false;
        let currentImages = property.images || [];

        // 1. Handle Image Deletions
        if (req.body.imagesToDelete) {
            const toDelete = Array.isArray(req.body.imagesToDelete) ? req.body.imagesToDelete : [req.body.imagesToDelete];

            const newImages = [];
            currentImages.forEach(url => {
                if (toDelete.includes(url)) {
                    try {
                        const relativePath = url;
                        const safePath = relativePath.startsWith('/') ? relativePath.substring(1) : relativePath;
                        const absolutePath = path.join(process.cwd(), safePath);
                        if (fs.existsSync(absolutePath)) {
                            fs.unlinkSync(absolutePath);
                        }
                    } catch (e) {
                        console.error(`Failed to delete image ${url}:`, e);
                    }
                    imagesChanged = true;
                } else {
                    newImages.push(url);
                }
            });
            currentImages = newImages;
        }

        // 2. Handle New Images Appending
        if (req.files && req.files['images']) {
            req.files['images'].forEach(file => {
                currentImages.push(`/uploads/documents/${file.filename}`);
            });
            imagesChanged = true;
        }

        if (imagesChanged) {
            property.images = currentImages;
            property.changed('images', true);
        }

        // 3. Handle Floor Plan Replacement
        if (req.files && req.files['floorPlan'] && req.files['floorPlan'][0]) {
            // Delete old
            if (property.floorPlan) {
                try {
                    const safePath = property.floorPlan.startsWith('/') ? property.floorPlan.substring(1) : property.floorPlan;
                    const absolutePath = path.join(process.cwd(), safePath);
                    if (fs.existsSync(absolutePath)) fs.unlinkSync(absolutePath);
                } catch (e) { }
            }
            property.floorPlan = `/uploads/documents/${req.files['floorPlan'][0].filename}`;
        }

        // 4. Handle Video Replacement
        if (req.files && req.files['video'] && req.files['video'][0]) {
            // Delete old
            if (property.video) {
                try {
                    const safePath = property.video.startsWith('/') ? property.video.substring(1) : property.video;
                    const absolutePath = path.join(process.cwd(), safePath);
                    if (fs.existsSync(absolutePath)) fs.unlinkSync(absolutePath);
                } catch (e) { }
            }
            property.video = `/uploads/documents/${req.files['video'][0].filename}`;
        }

        await property.save();

        res.status(200).json({ success: true, message: 'Property updated successfully', data: property });

    } catch (error) {
        console.error('Error updating property:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get Agent Properties
// @route   GET /api/v1/properties/agent/:id
const getAgentProperties = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;
        const agentId = req.params.id;
        console.log(`Fetching properties for agentId/userId: ${agentId}`);
        console.log(`Requesting user: ${req.user.id}, Type: ${req.user.userType}`);

        // Security check: Ensure requesting user is the agent or their company/admin
        // For now, strict check: req.user.id must match agentId OR admin
        if (req.user.id != agentId && req.user.userType !== 'admin' && req.user.userType !== 'company') {
            // Allow company to view their agent's properties? Yes.
            // But for now, let's just allow if it matches ID to fix the agent view.
            if (req.user.id.toString() !== agentId.toString()) {
                return res.status(403).json({ success: false, message: 'Not authorized to view these properties' });
            }
        }

        const { count, rows } = await db.Property.findAndCountAll({
            where: { userId: agentId },
            offset,
            limit: size,
            order: [['createdAt', 'DESC']],
            include: [{
                model: db.CompanyProfile,
                as: 'company',
                attributes: ['companyName'],
                required: false
            }]
        });

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });

    } catch (error) {
        console.error('Error fetching agent properties:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

const deleteProperty = async (req, res) => {
    try {
        const property = await db.Property.findByPk(req.params.id);
        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Authorization check: Admin or Owner
        let isAuthorized = false;
        if (req.user.userType === 'admin') {
            isAuthorized = true;
        } else if (req.user.id === property.userId) {
            isAuthorized = true;
        } else if (req.user.userType === 'company' && property.companyId === req.user.companyId) { // Need to verify companyId better but roughly ok for now
            // Simpler check if user is company, check company ownership
            const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
            if (company && company.id === property.companyId) isAuthorized = true;
        }

        if (!isAuthorized) {
            return res.status(403).json({ success: false, message: 'Not authorized to delete this property' });
        }

        // --- File Cleanup ---
        const filesToDelete = [];

        // Images array (it's a JSON/Array of strings)
        if (property.images && Array.isArray(property.images)) {
            filesToDelete.push(...property.images);
        }

        // Floor Plan
        if (property.floorPlan) {
            filesToDelete.push(property.floorPlan);
        }

        // Video
        if (property.video) {
            filesToDelete.push(property.video);
        }

        filesToDelete.forEach(filePath => {
            if (filePath) {
                try {
                    const safePath = filePath.startsWith('/') ? filePath.substring(1) : filePath;
                    const absolutePath = path.join(process.cwd(), safePath);
                    if (fs.existsSync(absolutePath)) {
                        fs.unlinkSync(absolutePath);
                        console.log(`Deleted file: ${absolutePath}`);
                    }
                } catch (e) {
                    console.error(`Failed to delete file ${filePath}:`, e);
                }
            }
        });

        // Cascade delete related records (Inquiries and Visits)
        await db.Inquiry.destroy({ where: { propertyId: property.id } });
        await db.Visit.destroy({ where: { propertyId: property.id } });

        await property.destroy();
        res.status(200).json({ success: true, message: 'Property deleted successfully' });

    } catch (error) {
        console.error('Error deleting property:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export {
    getProjects,
    getAdminProjects,
    getFeaturedProperties,
    getFeaturedPropertiesTop,
    getProperties,
    getPendingProperties,
    approveProperty,
    rejectProperty,
    approveProject,
    rejectProject,
    createPhase,
    createProperty,
    getPropertyById,
    getCompanyProjects,
    getAdminPendingProjects,
    getCompanyPendingProperties,
    approveCompanyProperty,
    rejectCompanyProperty,
    getCompanyProperties,
    getAgentProperties,
    updateProperty,
    deleteProperty
};
