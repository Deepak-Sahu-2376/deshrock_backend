import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
dotenv.config();

const transporter = nodemailer.createTransport({
    service: process.env.EMAIL_SERVICE,
    auth: {
        user: process.env.EMAIL_USER,
        pass: process.env.EMAIL_PASS,
    },
});

import { EMAIL_TEMPLATES } from '../utils/emailTemplates.js';

const sendEmail = async (to, subject, text, html) => {
    const mailOptions = {
        from: process.env.EMAIL_FROM || process.env.EMAIL_USER,
        to,
        subject,
        text,
        html,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent: ' + info.response);
        return true;
    } catch (error) {
        console.error('Error sending email:', error);
        return false;
    }
};

export const sendTemplateEmail = async (to, templateType, data) => {
    const template = EMAIL_TEMPLATES[templateType];
    if (!template) {
        console.error(`Email template type '${templateType}' not found.`);
        return false;
    }

    const { subject, html, text } = template(data);
    return await sendEmail(to, subject, text, html);
};

export default sendEmail;
