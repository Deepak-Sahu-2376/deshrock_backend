import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Phase = sequelize.define('Phase', {
    id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true
    },
    projectId: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
            model: 'Projects', // Make sure this matches your Table Name exactly
            key: 'id'
        }
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    phaseNumber: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    status: {
        type: DataTypes.STRING,
        defaultValue: 'PLANNING' // PLANNING, UNDER_CONSTRUCTION, COMPLETED
    },
    constructionStatus: {
        type: DataTypes.STRING
    },
    reraNumber: {
        type: DataTypes.STRING
    },
    description: {
        type: DataTypes.TEXT
    },
    totalUnits: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    bookedUnits: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    soldUnits: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    availableUnits: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    startingPrice: {
        type: DataTypes.DECIMAL(15, 2)
    },
    completionPercentage: {
        type: DataTypes.INTEGER,
        defaultValue: 0
    },
    approvedAt: {
        type: DataTypes.DATE
    },
    // Media
    phaseLogoUrl: {
        type: DataTypes.STRING
    },
    phaseBrochureUrl: {
        type: DataTypes.STRING
    },
    masterPlanUrl: {
        type: DataTypes.STRING
    },
    floorPlanUrls: {
        type: DataTypes.JSON, // Store array of URLs
        defaultValue: []
    },
    specifications: {
        type: DataTypes.TEXT // Comma separated or just text
    }
}, {
    timestamps: true,
    tableName: 'Phases'
});

export default Phase;
