import { DataTypes } from 'sequelize';
import bcrypt from 'bcryptjs';
import sequelize from '../config/database.js';

const User = sequelize.define('User', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true,
        validate: { isEmail: true }
    },
    identifier: { // Can be same as email, kept for flexibility
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    password: {
        type: DataTypes.STRING,
        allowNull: false
    },
    firstName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    lastName: {
        type: DataTypes.STRING,
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: true
    },
    userType: {
        type: DataTypes.ENUM('admin', 'buyer', 'agent', 'company', 'company_agent'),
        defaultValue: 'buyer'
    },
    isVerified: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
    },
    avatar: {
        type: DataTypes.STRING,
        allowNull: true
    },
    // Consents
    acceptTerms: { type: DataTypes.BOOLEAN, defaultValue: false },
    acceptPrivacyPolicy: { type: DataTypes.BOOLEAN, defaultValue: false },
    allowMarketingEmails: { type: DataTypes.BOOLEAN, defaultValue: false },
    allowSmsNotifications: { type: DataTypes.BOOLEAN, defaultValue: false },

    // For Buyers primarily
    profileComplete: { type: DataTypes.BOOLEAN, defaultValue: false }
}, {
    timestamps: true,
    hooks: {
        beforeCreate: async (user) => {
            if (user.password) {
                const salt = await bcrypt.genSalt(10);
                user.password = await bcrypt.hash(user.password, salt);
            }
        },
        beforeUpdate: async (user) => {
            if (user.changed('password')) {
                const salt = await bcrypt.genSalt(10);
                user.password = await bcrypt.hash(user.password, salt);
            }
        }
    }
});

User.prototype.matchPassword = async function (enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

export default User;
