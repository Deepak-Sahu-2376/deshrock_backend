import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Property = sequelize.define('Property', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    companyId: {
        type: DataTypes.INTEGER,
        allowNull: true, // Allow null for individual agents
        references: {
            model: 'CompanyProfiles',
            key: 'id'
        }
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: true, // Allow null for existing records
        references: {
            model: 'Users',
            key: 'id'
        }
    },
    // Basic Details
    title: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.TEXT, allowNull: false },
    propertyType: {
        type: DataTypes.ENUM('APARTMENT', 'VILLA', 'PLOT', 'COMMERCIAL'),
        allowNull: false
    },
    listingType: {
        type: DataTypes.ENUM('SALE', 'RENT', 'PG', 'COMMERCIAL_RENT'),
        allowNull: false
    },
    status: {
        type: DataTypes.ENUM('PENDING', 'APPROVED', 'REJECTED', 'PENDING_COMPANY'),
        defaultValue: 'PENDING'
    },
    rejectionReason: { type: DataTypes.TEXT, allowNull: true },

    // Specifications
    bedrooms: { type: DataTypes.INTEGER, allowNull: true },
    bathrooms: { type: DataTypes.INTEGER, allowNull: true },
    balconies: { type: DataTypes.INTEGER, allowNull: true },
    furnishingStatus: {
        type: DataTypes.ENUM('FULLY_FURNISHED', 'SEMI_FURNISHED', 'UNFURNISHED'),
        defaultValue: 'UNFURNISHED'
    },
    pantry: { type: DataTypes.BOOLEAN, defaultValue: false }, // For commercial
    washroom: { type: DataTypes.BOOLEAN, defaultValue: false }, // For commercial

    // Areas
    carpetArea: { type: DataTypes.FLOAT, allowNull: false },
    builtUpArea: { type: DataTypes.FLOAT, allowNull: true },
    superBuiltUpArea: { type: DataTypes.FLOAT, allowNull: true },

    // Floor Details
    floorNumber: { type: DataTypes.INTEGER, allowNull: true },
    totalFloors: { type: DataTypes.INTEGER, allowNull: true },
    unitNumber: { type: DataTypes.STRING, allowNull: true },
    tower: { type: DataTypes.STRING, allowNull: true },
    isCornerUnit: { type: DataTypes.BOOLEAN, defaultValue: false },

    // Pricing
    basePrice: { type: DataTypes.DECIMAL(15, 2), allowNull: true }, // For Sale
    monthlyRent: { type: DataTypes.DECIMAL(15, 2), allowNull: true }, // For Rent/PG
    securityDeposit: { type: DataTypes.DECIMAL(15, 2), allowNull: true },
    maintenanceCharges: { type: DataTypes.DECIMAL(15, 2), allowNull: true },
    floorRiseCharges: { type: DataTypes.DECIMAL(15, 2), defaultValue: 0 },

    // Parking
    coveredParkingSpots: { type: DataTypes.INTEGER, defaultValue: 0 },
    openParkingSpots: { type: DataTypes.INTEGER, defaultValue: 0 },

    // Location
    address: { type: DataTypes.TEXT, allowNull: false },
    city: { type: DataTypes.STRING, allowNull: false },
    state: { type: DataTypes.STRING, allowNull: false },
    pincode: { type: DataTypes.STRING, allowNull: false },
    country: { type: DataTypes.STRING, defaultValue: 'India' },
    latitude: { type: DataTypes.FLOAT, allowNull: true },
    longitude: { type: DataTypes.FLOAT, allowNull: true },

    // Features & Media
    amenities: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        defaultValue: []
    },
    images: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        defaultValue: []
    },
    video: { type: DataTypes.STRING, allowNull: true }, // URL
    floorPlan: { type: DataTypes.STRING, allowNull: true }, // URL

    isFeatured: { type: DataTypes.BOOLEAN, defaultValue: false },
    viewCount: { type: DataTypes.INTEGER, defaultValue: 0 }
}, {
    timestamps: true,
    indexes: [
        { fields: ['companyId'] },
        { fields: ['status'] },
        { fields: ['city'] },
        { fields: ['propertyType'] },
        { fields: ['listingType'] }
    ]
});

export default Property;
