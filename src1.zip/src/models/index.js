import sequelize from '../config/database.js';
import User from './User.js';
import CompanyProfile from './CompanyProfile.js';
import AgentProfile from './AgentProfile.js';
import Otp from './Otp.js';
import Property from './Property.js';
import Project from './Project.js';
import Document from './Document.js';
import Visit from './Visit.js';
import Inquiry from './Inquiry.js';
import Phase from './Phase.js';

const db = {
    sequelize,
    User,
    CompanyProfile,
    AgentProfile,
    Otp,
    Property,
    Project,
    Document,
    Inquiry,
    Visit,
    Phase
};

// ... (existing associations)

// User - Profiles (One-to-One)
User.hasOne(CompanyProfile, { foreignKey: 'userId', as: 'companyProfile' });
CompanyProfile.belongsTo(User, { foreignKey: 'userId', as: 'user' });

User.hasOne(AgentProfile, { foreignKey: 'userId', as: 'agentProfile' });
AgentProfile.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Company - Project
CompanyProfile.hasMany(Project, { foreignKey: 'companyId', as: 'projects' });
Project.belongsTo(CompanyProfile, { foreignKey: 'companyId', as: 'company' });

// Project - Phase
Project.hasMany(Phase, { foreignKey: 'projectId', as: 'phases' });
Phase.belongsTo(Project, { foreignKey: 'projectId', as: 'project' });

// Company - Agents (Company can have many agents)
CompanyProfile.hasMany(AgentProfile, { foreignKey: 'companyId', as: 'agents' });
AgentProfile.belongsTo(CompanyProfile, { foreignKey: 'companyId', as: 'company' });

// Company - Property
CompanyProfile.hasMany(Property, { foreignKey: 'companyId', as: 'properties' });
Property.belongsTo(CompanyProfile, { foreignKey: 'companyId', as: 'company' });

// User - Property (Individual Agents/Users)
User.hasMany(Property, { foreignKey: 'userId', as: 'properties' });
Property.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Property has many Inquiries
Property.hasMany(db.Inquiry, { foreignKey: 'propertyId', as: 'inquiries' });
db.Inquiry.belongsTo(Property, { foreignKey: 'propertyId', as: 'property' });

// Project has many Inquiries
Project.hasMany(db.Inquiry, { foreignKey: 'projectId', as: 'inquiries' });
db.Inquiry.belongsTo(Project, { foreignKey: 'projectId', as: 'project' });

// Visit Associations
User.hasMany(Visit, { foreignKey: 'userId', as: 'visits' }); // Buyer's visits
Visit.belongsTo(User, { foreignKey: 'userId', as: 'user' }); // Visit belongs to Buyer

Property.hasMany(Visit, { foreignKey: 'propertyId', as: 'visits' });
Visit.belongsTo(Property, { foreignKey: 'propertyId', as: 'property' });

User.hasMany(Visit, { foreignKey: 'agentId', as: 'agentVisits' }); // Agent's scheduled visits
Visit.belongsTo(User, { foreignKey: 'agentId', as: 'agent' }); // Visit assigned to Agent

export default db;
