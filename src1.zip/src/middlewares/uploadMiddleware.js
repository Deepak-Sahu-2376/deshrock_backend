import multer from 'multer';
import path from 'path';
import fs from 'fs';

// Helper to ensure directory exists
const ensureDir = (dirPath) => {
    if (!fs.existsSync(dirPath)) {
        fs.mkdirSync(dirPath, { recursive: true });
    }
};

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadPath = path.join(process.cwd(), 'uploads/documents');
        ensureDir(uploadPath);
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        // Safe filename: timestamp-original
        // Remove spaces/special chars from original name to be safe
        const safeName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, '_');
        cb(null, `${Date.now()}-${safeName}`);
    }
});

const fileFilter = (req, file, cb) => {
    // Logic for allowed files (PDF, Images, Videos)
    // Allowed extensions
    const allowedExts = /jpeg|jpg|png|gif|webp|pdf|mp4|mkv|webm|avi|mov/;
    // Allowed mimetypes
    const allowedMimes = /jpeg|jpg|png|gif|webp|pdf|mp4|mkv|webm|avi|quicktime|x-matroska|video\/x-msvideo/;

    const extname = allowedExts.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedMimes.test(file.mimetype);

    if (extname && mimetype) {
        cb(null, true);
    } else {
        cb(new Error(`File type not allowed: ${file.mimetype} / ${path.extname(file.originalname)}`), false);
    }
};

const upload = multer({
    storage: storage,
    limits: { fileSize: 500 * 1024 * 1024 }, // 500MB limit
    fileFilter: fileFilter
});

export default upload;
