
/**
 * Email Templates based on "Mail content.pdf"
 */

export const EMAIL_TEMPLATES = {
  // 1. Property Listed
  PROPERTY_LISTED: (data) => ({
    subject: `Your property ${data.propertyTitle} has been successfully listed on Deshrock`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>Great news! Your property <strong>${data.propertyTitle}</strong> has been successfully listed on Deshrock.</p>
      <h3>Listing Details:</h3>
      <ul>
        <li><strong>Property ID:</strong> ${data.propertyId}</li>
        <li><strong>Location:</strong> ${data.location}</li>
        <li><strong>Type:</strong> ${data.propertyType}</li>
        <li><strong>Price:</strong> ${data.price}</li>
        <li><strong>Status:</strong> Active & Visible to Buyers</li>
      </ul>
      <p>Your property is now live and available for thousands of verified buyers and renters on Deshrock. We will keep you updated on enquiries, views, and interested customers.</p>
      <p>You can view or edit your listing anytime:</p>
      <p><a href="${data.viewLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">View Listing</a></p>
      <p>If you need any help, our support team is here for you.</p>
      <p>Thank you for choosing Deshrock – India’s Home Discovery Platform.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nGreat news! Your property ${data.propertyTitle} has been successfully listed on Deshrock.\n\nListing Details:\n- Property ID: ${data.propertyId}\n- Location: ${data.location}\n- Type: ${data.propertyType}\n- Price: ${data.price}\n- Status: Active & Visible to Buyers\n\nYour property is now live. View it here: ${data.viewLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 2. OTP Login
  OTP_LOGIN: (data) => ({
    subject: `${data.otp} is your Deshrock Login OTP`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>To complete your login on Deshrock, please use the One-Time Password (OTP) given below:</p>
      <h2 style="font-size: 24px; font-weight: bold; color: #333;">${data.otp}</h2>
      <p>This OTP is valid for the next 10 minutes.</p>
      <p>Please do not share it with anyone.</p>
      <p>If you did not request this login, you can safely ignore this email.</p>
      <p>Thank you for using Deshrock.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nYour OTP for Deshrock login is: ${data.otp}\n\nValid for 10 minutes. Do not share this OTP.\n\nWarm regards,\nTeam Deshrock`
  }),

  // 2.1 Forgot Password OTP
  FORGOT_PASSWORD: (data) => ({
    subject: `${data.otp} is your Deshrock Password Reset OTP`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>You requested to reset your password on Deshrock. Please use the One-Time Password (OTP) given below:</p>
      <h2 style="font-size: 24px; font-weight: bold; color: #dc3545;">${data.otp}</h2>
      <p>This OTP is valid for the next 10 minutes.</p>
      <p>Please do not share it with anyone.</p>
      <p>If you did not request a password reset, please ignore this email and ensure your account is secure.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nYour OTP for Deshrock password reset is: ${data.otp}\n\nValid for 10 minutes. Do not share this OTP.\n\nWarm regards,\nTeam Deshrock`
  }),

  // 3. Suspicious Login
  SUSPICIOUS_LOGIN: (data) => ({
    subject: `Alert: Suspicious Login Attempt on Your Deshrock Account`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>We detected a login attempt on your Deshrock account from a new or unrecognized device.</p>
      <h3>Attempt Details:</h3>
      <ul>
        <li><strong>Date & Time:</strong> ${data.dateTime}</li>
        <li><strong>Device:</strong> ${data.device}</li>
        <li><strong>Location:</strong> ${data.location}</li>
      </ul>
      <p>If this was not you, your account may be at risk.</p>
      <p>Please secure your account immediately by reporting the activity and resetting your password:</p>
      <p><a href="${data.secureLink}" style="padding: 10px 20px; background-color: #dc3545; color: white; text-decoration: none; border-radius: 5px;">Secure My Account</a></p>
      <p>If this login attempt was made by you, you can safely ignore this email.</p>
      <p>Your security is extremely important to us.</p>
      <p>Thank you for trusting Deshrock – India’s Home Discovery Platform.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nWe detected a suspicious login attempt.\nDetails:\n- Date: ${data.dateTime}\n- Device: ${data.device}\n- Location: ${data.location}\n\nIf this wasn't you, secure your account: ${data.secureLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 4. Password Changed
  PASSWORD_CHANGED: (data) => ({
    subject: `Confirming Password Change for Deshrock Account`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>This is to confirm that the password for your Deshrock account was successfully changed.</p>
      <h3>Password Change Details:</h3>
      <ul>
        <li><strong>Date & Time:</strong> ${data.dateTime}</li>
        <li><strong>Device:</strong> ${data.device}</li>
        <li><strong>Location:</strong> ${data.location}</li>
      </ul>
      <p>If you made this change, no further action is required.</p>
      <p>If you did NOT update your password, your account may be compromised. Please secure your account immediately:</p>
      <p><a href="${data.resetLink}" style="padding: 10px 20px; background-color: #dc3545; color: white; text-decoration: none; border-radius: 5px;">Reset Password</a></p>
      <p><a href="${data.reportLink}">Report Unauthorized Activity</a></p>
      <p>Your security is extremely important to us.</p>
      <p>Thank you for using Deshrock – India’s Home Discovery Platform.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nYour Deshrock password was changed.\nDetails:\n- Date: ${data.dateTime}\n- Device: ${data.device}\n- Location: ${data.location}\n\nIf you didn't do this, reset your password immediately: ${data.resetLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 5. New Login (Safe)
  NEW_LOGIN: (data) => ({
    subject: `New login to your Deshrock account`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>We noticed a new login to your Deshrock account.</p>
      <h3>Login Details:</h3>
      <ul>
        <li><strong>Date & Time:</strong> ${data.dateTime}</li>
        <li><strong>Device:</strong> ${data.device}</li>
        <li><strong>Location:</strong> ${data.location}</li>
      </ul>
      <p>If this was you, no further action is needed. You’re all set!</p>
      <p>If you did NOT log in, please report it immediately so we can secure your account:</p>
      <p><a href="${data.reportLink}" style="padding: 10px 20px; background-color: #dc3545; color: white; text-decoration: none; border-radius: 5px;">Report Activity</a></p>
      <p>Your security is our top priority.</p>
      <p>Thank you for using Deshrock – India’s Home Discovery Platform.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nNew login detected.\nDetails:\n- Date: ${data.dateTime}\n- Device: ${data.device}\n- Location: ${data.location}\n\nIf not you, report here: ${data.reportLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 8. Company Registration Submitted
  COMPANY_REGISTRATION_SUBMITTED: (data) => ({
    subject: `Company Registration Submitted: ${data.companyName}`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>Thank you for registering <strong>${data.companyName}</strong> on Deshrock.</p>
      <p>Your company details have been successfully submitted and are now under verification by our team.</p>
      <h3>What Happens Next:</h3>
      <ul>
        <li>Our team will review your documents and company details</li>
        <li>Verification may take 24–48 hours</li>
        <li>You will receive an email once your company is verified</li>
      </ul>
      <p>You can continue exploring your dashboard, but certain features will be limited until the verification is complete.</p>
      <p>If you need any assistance, feel free to reach out to our support team.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nThank you for registering ${data.companyName} on Deshrock.\nYour details are under verification.\nVerification may take 24-48 hours.\n\nWarm regards,\nTeam Deshrock`
  }),

  // 8. Company Verified
  COMPANY_VERIFIED: (data) => ({
    subject: `Your company ${data.companyName} has been verified on Deshrock`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>Great news! Your company <strong>${data.companyName}</strong> has been successfully verified on Deshrock.</p>
      <p>You now have full access to:</p>
      <ul>
        <li>Add and manage property listings</li>
        <li>Publish projects</li>
        <li>Receive enquiries from buyers</li>
        <li>Add agents to your company</li>
        <li>Access analytics and performance dashboards</li>
      </ul>
      <p>Start managing your company profile here:</p>
      <p><a href="${data.dashboardLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Go to Dashboard</a></p>
      <p>Thank you for choosing Deshrock – India’s Home Discovery Platform.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nYour company ${data.companyName} is verified!\nYou now have full access to all features.\n\nGo to Dashboard: ${data.dashboardLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 10. Company Verification Rejected
  COMPANY_REJECTED: (data) => ({
    subject: `Update regarding your company verification for ${data.companyName}`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>We were unable to verify your company <strong>${data.companyName}</strong> due to incomplete or mismatched documents.</p>
      <h3>Reason for Rejection:</h3>
      <ul>
        ${data.reasons.map(r => `<li>${r}</li>`).join('')}
      </ul>
      <p>To complete your verification, please update and reupload the required documents here:</p>
      <p><a href="${data.uploadLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Upload Documents</a></p>
      <p>Our team will re-review your details once the documents are submitted.</p>
      <p>If you need assistance, we’re here to help.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nWe couldn't verify ${data.companyName}.\nReasons:\n${data.reasons.join('\n')}\n\nPlease update documents: ${data.uploadLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 11. Project Added
  PROJECT_ADDED: (data) => ({
    subject: `Your project ${data.projectName} has been added`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>Your project <strong>${data.projectName}</strong> has been successfully added to your company profile on Deshrock.</p>
      <h3>Project Details:</h3>
      <ul>
        <li><strong>Project Name:</strong> ${data.projectName}</li>
        <li><strong>Location:</strong> ${data.location}</li>
        <li><strong>Project Type:</strong> ${data.projectType}</li>
        <li><strong>Status:</strong> ${data.status}</li>
        <li><strong>Project ID:</strong> ${data.projectId}</li>
      </ul>
      <p>If the project is under review, our team will verify the details shortly.</p>
      <p>You may continue adding units, images, amenities, and pricing.</p>
      <p>Manage your project here:</p>
      <p><a href="${data.viewLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">View Project</a></p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nYour project ${data.projectName} has been added.\n\nView Project: ${data.viewLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 12. Agent Added
  AGENT_ADDED: (data) => ({
    subject: `New agent added to ${data.companyName}`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>A new agent <strong>${data.agentName}</strong> has been successfully added to your company <strong>${data.companyName}</strong> on Deshrock.</p>
      <h3>Agent Details:</h3>
      <ul>
        <li><strong>Name:</strong> ${data.agentName}</li>
        <li><strong>Email:</strong> ${data.agentEmail}</li>
        <li><strong>Phone:</strong> ${data.agentPhone}</li>
        <li><strong>Role:</strong> ${data.role}</li>
        <li><strong>Added On:</strong> ${data.addedDate}</li>
      </ul>
      <p>The agent can now:</p>
      <ul>
        <li>Add and manage property listings</li>
        <li>Respond to enquiries</li>
        <li>Access assigned projects</li>
        <li>Use the agent dashboard</li>
      </ul>
      <p>If this was not authorized by you, please report it immediately:</p>
      <p><a href="${data.reportLink}" style="padding: 10px 20px; background-color: #dc3545; color: white; text-decoration: none; border-radius: 5px;">Report Activity</a></p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nAgent ${data.agentName} added to ${data.companyName}.\n\nIf unauthorized, report here: ${data.reportLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 13. Project Approved
  PROJECT_APPROVED: (data) => ({
    subject: `Your project ${data.projectName} is now live!`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>Great news! Your project <strong>${data.projectName}</strong> has been successfully approved by the Deshrock verification team.</p>
      <h3>Project Details:</h3>
      <ul>
        <li><strong>Project Name:</strong> ${data.projectName}</li>
        <li><strong>Location:</strong> ${data.location}</li>
        <li><strong>Project Type:</strong> ${data.projectType}</li>
        <li><strong>Approval Date:</strong> ${data.approvalDate}</li>
        <li><strong>Status:</strong> Active & Visible to Users</li>
      </ul>
      <p>Your project is now live and visible to thousands of potential buyers and investors.</p>
      <p>You may continue adding units, images, pricing, and amenities for better reach.</p>
      <p>Manage your project here:</p>
      <p><a href="${data.viewLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">View Project</a></p>
      <p>Thank you for choosing Deshrock – India’s Home Discovery Platform.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nYour project ${data.projectName} is approved and live!\n\nView Project: ${data.viewLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 14. Project Rejected
  PROJECT_REJECTED: (data) => ({
    subject: `Action Required: Your project ${data.projectName} needs correction`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>We reviewed your project <strong>${data.projectName}</strong>, but unfortunately we couldn’t approve it due to issues that require correction.</p>
      <h3>Reason for Rejection:</h3>
      <ul>
        ${data.reasons.map(r => `<li>${r}</li>`).join('')}
      </ul>
      <p>Please update the required details and resubmit your project for verification.</p>
      <p><a href="${data.fixLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Fix Project Details</a></p>
      <p>Once submitted, our team will re-evaluate it promptly.</p>
      <p>If you need assistance, feel free to contact our support team.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nYour project ${data.projectName} was not approved.\nReasons:\n${data.reasons.join('\n')}\n\nplease fix here: ${data.fixLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 15. Enquiry Received
  ENQUIRY_RECEIVED: (data) => ({
    subject: `New Enquiry for your property: ${data.propertyTitle}`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>You’ve received a new enquiry for your property <strong>${data.propertyTitle}</strong> listed on Deshrock.</p>
      <h3>Enquiry Details:</h3>
      <ul>
        <li><strong>Interested Buyer:</strong> ${data.buyerName}</li>
        <li><strong>Phone:</strong> ${data.buyerPhone}</li>
        <li><strong>Email:</strong> ${data.buyerEmail}</li>
        <li><strong>Message:</strong> "${data.message}"</li>
        <li><strong>Received On:</strong> ${data.receivedDate}</li>
      </ul>
      <p>Please respond promptly to increase your chances of conversion.</p>
      <p><a href="${data.viewLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">View Enquiry</a></p>
      <p>Thank you for using Deshrock to reach potential buyers.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nNew enquiry for ${data.propertyTitle} from ${data.buyerName}.\nMessage: "${data.message}"\n\nView Enquiry: ${data.viewLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 17. Unit Added
  UNIT_ADDED: (data) => ({
    subject: `Unit added to project ${data.projectName}`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>A new unit has been successfully added to your project <strong>${data.projectName}</strong> on Deshrock.</p>
      <h3>Unit Details:</h3>
      <ul>
        <li><strong>Unit Number:</strong> ${data.unitNumber}</li>
        <li><strong>Type:</strong> ${data.unitType}</li>
        <li><strong>Size:</strong> ${data.size}</li>
        <li><strong>Price:</strong> ${data.price}</li>
        <li><strong>Status:</strong> ${data.status}</li>
        <li><strong>Added On:</strong> ${data.addedDate}</li>
      </ul>
      <p>If the unit is under review, our team will verify it shortly.</p>
      <p><a href="${data.viewLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Manage Unit</a></p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nUnit ${data.unitNumber} added to ${data.projectName}.\n\nManage here: ${data.viewLink}\n\nWarm regards,\nTeam Deshrock`
  }),

  // 24. Ticket Resolved
  TICKET_RESOLVED: (data) => ({
    subject: `Support Ticket Resolved: ${data.ticketId}`,
    html: `
      <p>Hi ${data.userName},</p>
      <p>Your support ticket <strong>${data.ticketId}</strong> has been successfully resolved.</p>
      <h3>Ticket Summary:</h3>
      <ul>
        <li><strong>Issue Type:</strong> ${data.issueType}</li>
        <li><strong>Description:</strong> ${data.description}</li>
        <li><strong>Resolved On:</strong> ${data.resolvedDate}</li>
        <li><strong>Status:</strong> Resolved</li>
      </ul>
      <p>If you feel the issue is not completely resolved, you may reopen the ticket:</p>
      <p><a href="${data.reopenLink}" style="padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px;">Reopen Ticket</a></p>
      <p>Thank you for contacting Deshrock Support.</p>
      <p>Warm regards,<br>Team Deshrock</p>
    `,
    text: `Hi ${data.userName},\n\nTicket ${data.ticketId} resolved.\n\nWarm regards,\nTeam Deshrock`
  }),
};
