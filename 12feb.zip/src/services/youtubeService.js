import { google } from 'googleapis';
import fs from 'fs';

const oauth2Client = new google.auth.OAuth2(
    process.env.YOUTUBE_CLIENT_ID,
    process.env.YOUTUBE_CLIENT_SECRET,
    process.env.YOUTUBE_REDIRECT_URI || 'https://developers.google.com/oauthplayground'
);

// Set credentials if refresh token is available
if (process.env.YOUTUBE_REFRESH_TOKEN) {
    oauth2Client.setCredentials({
        refresh_token: process.env.YOUTUBE_REFRESH_TOKEN
    });
}

const youtube = google.youtube({
    version: 'v3',
    auth: oauth2Client
});

/**
 * Uploads a video to YouTube.
 * @param {string} filePath - Absolute path to the video file.
 * @param {string} title - Video title.
 * @param {string} description - Video description.
 * @returns {Promise<string>} - The YouTube Video ID.
 */
export const uploadToYouTube = async (filePath, title, description) => {
    try {
        if (!process.env.YOUTUBE_REFRESH_TOKEN) {
            console.warn('YOUTUBE_REFRESH_TOKEN is missing. Skipping YouTube upload.');
            return null; // Or throw error? For now, let's warn so we don't break capability if not configured
        }

        const fileSize = fs.statSync(filePath).size;
        console.log(`Starting YouTube upload: ${filePath} (${fileSize} bytes)`);

        const res = await youtube.videos.insert({
            part: 'snippet,status',
            requestBody: {
                snippet: {
                    title: title,
                    description: description,
                    categoryId: '22', // People & Blogs or 28 (Science & Tech)
                },
                status: {
                    privacyStatus: 'unlisted', // 'private', 'public', or 'unlisted'
                },
            },
            media: {
                body: fs.createReadStream(filePath),
            },
        });

        console.log(`Video uploaded successfully. ID: ${res.data.id}`);
        return res.data.id;
    } catch (error) {
        console.error('Error uploading to YouTube:', error);
        throw error;
    }
};
