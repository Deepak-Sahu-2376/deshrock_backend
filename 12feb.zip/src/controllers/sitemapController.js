import { SitemapStream, streamToPromise } from 'sitemap';
import { createGzip } from 'zlib';
import db from '../models/index.js';
import { Sequelize } from 'sequelize';

const encodeUrlPath = (str) => encodeURIComponent(str).replace(/%20/g, '-');

export const getSitemap = async (req, res) => {
    try {
        res.header('Content-Type', 'application/xml');
        res.header('Content-Encoding', 'gzip');

        const sitemap = new SitemapStream({ hostname: process.env.CLIENT_URL || 'https://deshrock.com' });
        const pipeline = sitemap.pipe(createGzip());

        // Static URLs
        sitemap.write({ url: '/', changefreq: 'daily', priority: 1.0 });
        sitemap.write({ url: '/about', changefreq: 'monthly', priority: 0.8 });
        sitemap.write({ url: '/properties', changefreq: 'daily', priority: 0.9 });
        sitemap.write({ url: '/projects', changefreq: 'daily', priority: 0.9 });
        sitemap.write({ url: '/contact', changefreq: 'yearly', priority: 0.7 });

        // Dynamic Properties
        const properties = await db.Property.findAll({
            attributes: ['id', 'city', 'title', 'updatedAt'],
            where: { status: 'APPROVED' }
        });

        properties.forEach(property => {
            const citySlug = property.city ? property.city.toLowerCase().replace(/\s+/g, '-') : 'city';
            const titleSlug = property.title ? property.title.toLowerCase().replace(/\s+/g, '-') : 'property';
            sitemap.write({
                url: `/property/${encodeUrlPath(titleSlug)}/${encodeUrlPath(citySlug)}/${property.id}`,
                lastmod: property.updatedAt,
                changefreq: 'weekly',
                priority: 0.8
            });
        });

        // Dynamic Projects
        const projects = await db.Project.findAll({
            attributes: ['id', 'city', 'name', 'updatedAt'],
            where: { approvalStatus: 'APPROVED' }
        });

        projects.forEach(project => {
            const citySlug = project.city ? project.city.toLowerCase().replace(/\s+/g, '-') : 'city';
            const titleSlug = project.name ? project.name.toLowerCase().replace(/\s+/g, '-') : 'project';
            sitemap.write({
                url: `/projects/${encodeUrlPath(titleSlug)}/${encodeUrlPath(citySlug)}/${project.id}`,
                lastmod: project.updatedAt,
                changefreq: 'weekly',
                priority: 0.8
            });
        });

        // City Categories for Properties
        const propertyCities = await db.Property.findAll({
            attributes: [[Sequelize.fn('DISTINCT', Sequelize.col('city')), 'city']],
            where: { status: 'APPROVED' }
        });

        propertyCities.forEach(p => {
            const city = p.getDataValue('city');
            if (city) {
                sitemap.write({
                    url: `/properties?city=${encodeURIComponent(city)}`,
                    changefreq: 'daily',
                    priority: 0.8
                });
            }
        });

        // City Categories for Projects
        const projectCities = await db.Project.findAll({
            attributes: [[Sequelize.fn('DISTINCT', Sequelize.col('city')), 'city']],
            where: { approvalStatus: 'APPROVED' }
        });

        projectCities.forEach(p => {
            const city = p.getDataValue('city');
            if (city) {
                sitemap.write({
                    url: `/projects?city=${encodeURIComponent(city)}`,
                    changefreq: 'daily',
                    priority: 0.8
                });
            }
        });

        sitemap.end();
        pipeline.pipe(res).on('error', (e) => { throw e });

    } catch (e) {
        console.error("Sitemap Generation Error:", e);
        res.status(500).end();
    }
};
