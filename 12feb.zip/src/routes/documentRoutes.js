import express from 'express';
import multer from 'multer';
import { protect } from '../middlewares/authMiddleware.js';
import db from '../models/index.js';

const storage = multer.diskStorage({
    destination(req, file, cb) { cb(null, 'uploads/') },
    filename(req, file, cb) { cb(null, `doc-${Date.now()}-${file.originalname}`) }
});
const upload = multer({ storage });

const router = express.Router();

router.post('/upload', protect, upload.single('file'), async (req, res) => {
    if (!req.file) return res.status(400).json({ success: false, message: 'No file uploaded' });

    try {
        const { documentType, description } = req.body;
        const userId = req.user.id;

        let entityType = 'USER';
        // Normalize userType to entityType ENUM
        if (req.user.userType && req.user.userType.toLowerCase().includes('agent')) {
            entityType = 'AGENT';
        } else if (req.user.userType && req.user.userType.toLowerCase().includes('company')) {
            entityType = 'COMPANY';
        }

        const newDoc = await db.Document.create({
            entityId: userId,
            entityType: entityType,
            documentType: documentType || 'registration_document',
            fileName: req.file.originalname,
            fileUrl: `/uploads/${req.file.filename}`, // multer default dest is 'uploads/', no 'documents' subfolder in this specific route config?
            // Wait, this route uses its OWN multer config, separate from my new uploadMiddleware.js
            // The local storage config here puts it in 'uploads/'.
            // Consistency check: uploadMiddleware puts in 'uploads/documents/'.
            // I should ideally use the same middleware, but risking breaking change on this existing route if I change storage destination.
            // I'll stick to what this route produces: `uploads/` + filename.
            mimeType: req.file.mimetype,
            fileSize: req.file.size,
            status: 'PENDING',
            description: description // If description field is added to Document model? It wasn't in my plan.
            // I did NOT add 'description' to Document model. So I will ignore it or add it later if needed.
        });

        res.json({
            success: true,
            message: 'File uploaded and saved successfully',
            data: newDoc
        });
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).json({ success: false, message: 'Failed to save document record' });
    }
});




// GET /api/v1/documents/entity/:entityType/:entityId
router.get('/entity/:entityType/:entityId', protect, async (req, res) => {
    // Return mock documents since real Document model integration is pending
    // This allows the frontend to receive a valid structure and display "No documents" or mock ones.
    const { entityType, entityId } = req.params;

    // Structure must match    const { entityType, entityId } = req.params;
    // Map frontend 'AGENT' -> DB 'AGENT' (or User ID logic?)
    // The previous implementation used entityId as the AgentProfile/CompanyProfile ID, OR UserID?
    // Let's assume entityId passes the User ID (based on AdminAgents.jsx: agent.id).

    console.log('Fetching documents for:', entityType, entityId);
    console.log('Query params:', req.query); // Added log for query params

    try {
        let userId = entityId;

        // If entityType is AGENT or COMPANY, and the ID looks like a profile ID, we might face a mismatch if we stored UserID.
        // Let's check:
        // agent.id in frontend is AgentProfile.id.
        // documents are stored with entityId = User.id.
        // So I must find the User.id for this AgentProfile.id.

        if (entityType === 'AGENT') {
            const agent = await db.AgentProfile.findByPk(entityId);
            if (agent) userId = agent.userId;
        } else if (entityType === 'COMPANY') {
            const company = await db.CompanyProfile.findByPk(entityId);
            if (company) userId = company.userId;
        }

        // Now fetch documents
        const docs = await db.Document.findAll({
            where: {
                entityId: userId,
                entityType: entityType // stored as 'AGENT', 'COMPANY'
            },
            order: [['createdAt', 'DESC']]
        });

        res.json({
            success: true,
            data: {
                content: docs
            }
        });
    } catch (error) {
        console.error('Error fetching docs:', error);
        res.status(500).json({ success: false, message: 'Failed to fetch documents' });
    }
});

export default router;
