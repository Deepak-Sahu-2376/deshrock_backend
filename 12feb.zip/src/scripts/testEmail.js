import dotenv from 'dotenv';
dotenv.config();
import sendEmail from '../services/emailService.js';

const testEmail = async () => {
    const args = process.argv.slice(2);
    const to = args[0] || process.env.SMTP_USER; // Send to arg or self

    const subject = 'Test Email from Deshrock Backend';
    const text = 'This is a test email to verify the new Namecheap Private Email configuration.';
    const html = '<p>This is a <strong>test email</strong> to verify the new Namecheap Private Email configuration.</p>';

    console.log(`Attempting to send email to ${to}...`);
    try {
        const result = await sendEmail(to, subject, text, html);
        if (result) {
            console.log('✅ Email sent successfully!');
        } else {
            console.error('❌ Failed to send email.');
        }
    } catch (error) {
        console.error('❌ Error executing sendEmail:', error);
    }
};

testEmail();
