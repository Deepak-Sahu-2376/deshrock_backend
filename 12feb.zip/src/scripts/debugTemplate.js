import dotenv from 'dotenv';
dotenv.config();
import { sendTemplateEmail } from '../services/emailService.js';

const debugTemplate = async () => {
    const to = process.env.SMTP_USER; // Send to self
    const templateType = 'OTP_LOGIN';
    const data = {
        userName: 'TestUser',
        otp: '123456'
    };

    console.log(`Attempting to send '${templateType}' email to ${to}...`);
    try {
        const result = await sendTemplateEmail(to, templateType, data);
        if (result) {
            console.log('✅ Template Email sent successfully!');
        } else {
            console.error('❌ Failed to send template email.');
        }
    } catch (error) {
        console.error('❌ Error executing sendTemplateEmail:', error);
    }
};

debugTemplate();
