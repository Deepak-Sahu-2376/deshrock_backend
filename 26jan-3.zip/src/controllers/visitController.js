import Visit from '../models/Visit.js';
import Property from '../models/Property.js';
import User from '../models/User.js';
import CompanyProfile from '../models/CompanyProfile.js';
import { Op } from 'sequelize';

export const scheduleVisit = async (req, res, next) => {
    try {
        const { propertyId, preferredVisitTime, message } = req.body;
        const userId = req.user.id; // From authMiddleware

        // Basic validation
        if (!propertyId || !preferredVisitTime) {
            return res.status(400).json({ success: false, message: 'Property and Time are required' });
        }

        // Find property to get owner/agent
        const property = await Property.findByPk(propertyId, {
            include: [
                {
                    model: CompanyProfile,
                    as: 'company'
                }
            ]
        });

        if (!property) {
            return res.status(404).json({ success: false, message: 'Property not found' });
        }

        // Determine Agent ID (Recipient of the visit request)
        // logic:
        // 1. If Created by Agent (Individual or Company Agent) -> Go to Agent (property.userId)
        // 2. If Created by Company (Admin) -> Go to Company (property.userId is Company Admin ID)
        // 3. If Created by Admin -> Go to Admin (property.userId is Admin ID)
        // Fallback: If userId is null (e.g., deleted user) but companyId exists, route to Company Admin.

        let agentId = property.userId;

        if (!agentId && property.company) {
            agentId = property.company.userId;
        }

        // Check if agentId is valid/exists in User table? 
        // (Optional safety check, but assuming relational integrity or lazy error handling)

        const visit = await Visit.create({
            userId,
            propertyId,
            agentId,
            preferredVisitTime,
            message,
            status: 'PENDING'
        });

        res.status(201).json({ success: true, data: visit, message: 'Visit scheduled successfully' });
    } catch (error) {
        next(error);
    }
};

// For Buyers
export const getMyVisits = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 0, size = 10, sort = 'createdAt,desc' } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        // Parse sort: "field,order"
        const [sortField, sortOrder] = sort.split(',');

        const { count, rows } = await Visit.findAndCountAll({
            where: { userId },
            include: [
                {
                    model: Property,
                    as: 'property',
                    attributes: ['id', 'title', 'address', 'images', 'basePrice', 'monthlyRent', 'listingType']
                },
                {
                    model: User,
                    as: 'agent',
                    attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'userType']
                }
            ],
            limit,
            offset,
            order: [[sortField || 'createdAt', sortOrder || 'DESC']]
        });

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalElements: count,
                totalPages: Math.ceil(count / limit),
                number: parseInt(page)
            }
        });
    } catch (error) {
        next(error);
    }
};

// For Agents: Get Today's Visits
export const getAgentTodayVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const startOfDay = new Date();
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date();
        endOfDay.setHours(23, 59, 59, 999);

        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const { count, rows } = await Visit.findAndCountAll({
            where: {
                agentId,
                preferredVisitTime: {
                    [Op.between]: [startOfDay, endOfDay]
                }
            },
            include: [
                {
                    model: User,
                    as: 'user', // The buyer
                    attributes: ['id', 'firstName', 'lastName', 'email', 'phone']
                },
                {
                    model: Property,
                    as: 'property',
                    attributes: ['id', 'title', 'address']
                }
            ],
            limit,
            offset,
            order: [['preferredVisitTime', 'ASC']]
        });

        // Map for frontend convenience if needed (frontend expects fullName)
        const content = rows.map(v => {
            const json = v.toJSON();
            return {
                ...json,
                fullName: json.user ? `${json.user.firstName} ${json.user.lastName}` : 'Unknown Buyer',
                propertyId: json.property ? json.property.id : 'Unknown'
            };
        });

        res.status(200).json({
            success: true,
            content: content, // Direct content array or wrapped? Frontend AgentContext handles both.
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

// For Agents: Get Upcoming Visits
export const getAgentUpcomingVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const now = new Date();

        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const { count, rows } = await Visit.findAndCountAll({
            where: {
                agentId,
                preferredVisitTime: {
                    [Op.gt]: now
                }
            },
            include: [
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'firstName', 'lastName', 'email', 'phone']
                },
                {
                    model: Property,
                    as: 'property',
                    attributes: ['id', 'title', 'address']
                }
            ],
            limit,
            offset,
            order: [['preferredVisitTime', 'ASC']]
        });

        const content = rows.map(v => {
            const json = v.toJSON();
            return {
                ...json,
                fullName: json.user ? `${json.user.firstName} ${json.user.lastName}` : 'Unknown Buyer',
                propertyId: json.property ? json.property.id : 'Unknown'
            };
        });

        res.status(200).json({
            success: true,
            content: content,
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

export const updateVisitStatus = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { status } = req.body;
        const agentId = req.user.id;

        const visit = await Visit.findByPk(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        // Only assigned agent or admin can update
        // Check if user is agent or admin... logic omitted for brevity, assuming middleware or simple check
        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        visit.status = status;
        await visit.save();

        res.status(200).json({ success: true, message: 'Visit status updated', data: visit });
    } catch (error) {
        next(error);
    }
};

export const cancelVisitByUser = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { reason } = req.body; // Optional reason
        const userId = req.user.id;

        const visit = await Visit.findByPk(id);
        if (!visit) {
            return res.status(404).json({ success: false, message: 'Visit not found' });
        }

        // Ensure the visit belongs to the requesting user
        if (visit.userId !== userId) {
            return res.status(403).json({ success: false, message: 'Not authorized to cancel this visit' });
        }

        // Check if status allows cancellation
        if (['CANCELLED', 'REJECTED', 'COMPLETED'].includes(visit.status)) {
            return res.status(400).json({ success: false, message: `Visit is already ${visit.status}` });
        }

        visit.status = 'CANCELLED';
        // We could append the reason to a notes field or message if needed, 
        // strictly following the schema, 'message' is usually the initial message.
        // Let's prepend/append to adminNotes or message if strictly needed, but for now just status update.
        if (reason) {
            // Optional: append reason to existing message or adminNotes?
            // Since there's no explicit 'cancellationReason' field in the model shown earlier,
            // we'll just log it or append to adminNotes for record if desired.
            // For simplicity and to match common patterns, we update status.
            // If the user wants to persist reason, we might need a schema update, but let's stick to current schema.
            // Let's verify schema: 
            // message: { type: DataTypes.TEXT, allowNull: true },
            // adminNotes: { type: DataTypes.TEXT, allowNull: true }

            // Let's separate it safely.
            const cancellationNote = `[Cancelled by User]: ${reason}`;
            visit.adminNotes = visit.adminNotes ? `${visit.adminNotes}\n${cancellationNote}` : cancellationNote;
        }

        await visit.save();

        res.status(200).json({ success: true, message: 'Visit cancelled successfully', data: visit });
    } catch (error) {
        next(error);
    }
};

// For Agents: Get Pending Visit Requests
export const getAgentPendingVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const { count, rows } = await Visit.findAndCountAll({
            where: {
                agentId,
                status: 'PENDING'
            },
            include: [
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'firstName', 'lastName', 'email', 'phone']
                },
                {
                    model: Property,
                    as: 'property',
                    attributes: ['id', 'title', 'address']
                }
            ],
            limit,
            offset,
            order: [['preferredVisitTime', 'ASC']]
        });

        // Map for frontend 
        const content = rows.map(v => {
            const json = v.toJSON();
            return {
                ...json,
                fullName: json.user ? `${json.user.firstName} ${json.user.lastName}` : 'Unknown Buyer',
                email: json.user ? json.user.email : '',
                phone: json.user ? json.user.phone : '',
                propertyId: json.property ? json.property.id : 'Unknown'
            };
        });

        res.status(200).json({
            success: true,
            content: content,
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

// Confirm Visit (Agent)
export const confirmVisit = async (req, res, next) => {
    try {
        const { id } = req.params;
        const agentId = req.user.id;

        const visit = await Visit.findByPk(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        visit.status = 'CONFIRMED';
        await visit.save();

        res.status(200).json({ success: true, message: 'Visit confirmed', data: visit });
    } catch (error) {
        next(error);
    }
};

// Complete Visit (Agent)
export const completeVisit = async (req, res, next) => {
    try {
        const { id } = req.params;
        const agentId = req.user.id;

        const visit = await Visit.findByPk(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        visit.status = 'COMPLETED';
        await visit.save();

        res.status(200).json({ success: true, message: 'Visit completed', data: visit });
    } catch (error) {
        next(error);
    }
};

// Cancel Visit (Agent)
export const cancelVisitByAgent = async (req, res, next) => {
    try {
        const { id } = req.params;
        const { reason } = req.body;
        const agentId = req.user.id;

        const visit = await Visit.findByPk(id);
        if (!visit) return res.status(404).json({ success: false, message: 'Visit not found' });

        if (visit.agentId !== agentId && req.user.userType !== 'admin') {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        visit.status = 'CANCELLED';
        if (reason) {
            const cancellationNote = `[Cancelled by Agent]: ${reason}`;
            visit.adminNotes = visit.adminNotes ? `${visit.adminNotes}\n${cancellationNote}` : cancellationNote;
        }
        await visit.save();

        res.status(200).json({ success: true, message: 'Visit cancelled', data: visit });
    } catch (error) {
        next(error);
    }
};

// For Agents: Get Confirmed Visit Requests
export const getAgentConfirmedVisits = async (req, res, next) => {
    try {
        const agentId = req.user.id;
        const { page = 0, size = 20 } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;

        const { count, rows } = await Visit.findAndCountAll({
            where: {
                agentId,
                status: 'CONFIRMED'
            },
            include: [
                {
                    model: User,
                    as: 'user',
                    attributes: ['id', 'firstName', 'lastName', 'email', 'phone']
                },
                {
                    model: Property,
                    as: 'property',
                    attributes: ['id', 'title', 'address']
                }
            ],
            limit,
            offset,
            order: [['preferredVisitTime', 'ASC']]
        });

        // Map for frontend
        const content = rows.map(v => {
            const json = v.toJSON();
            return {
                ...json,
                fullName: json.user ? `${json.user.firstName} ${json.user.lastName}` : 'Unknown Buyer',
                email: json.user ? json.user.email : '',
                phone: json.user ? json.user.phone : '',
                propertyId: json.property ? json.property.id : 'Unknown'
            };
        });

        res.status(200).json({
            success: true,
            content: content,
            totalElements: count
        });
    } catch (error) {
        next(error);
    }
};

// For Owners (Buyers/Agents): Get Visits on My Properties
export const getOwnerVisits = async (req, res, next) => {
    try {
        const userId = req.user.id;
        const { page = 0, size = 10, sort = 'createdAt,desc' } = req.query;
        const limit = parseInt(size);
        const offset = parseInt(page) * limit;
        const [sortField, sortOrder] = sort.split(',');

        const { count, rows } = await Visit.findAndCountAll({
            where: { agentId: userId }, // Visits assigned to me
            include: [
                {
                    model: User,
                    as: 'user', // The visitor
                    attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'avatar']
                },
                {
                    model: Property,
                    as: 'property',
                    attributes: ['id', 'title', 'address', 'images']
                }
            ],
            limit,
            offset,
            order: [[sortField || 'createdAt', sortOrder || 'DESC']]
        });

        res.status(200).json({
            success: true,
            data: {
                content: rows,
                totalElements: count,
                totalPages: Math.ceil(count / limit),
                number: parseInt(page)
            }
        });
    } catch (error) {
        next(error);
    }
};
