import express from 'express';
import { createInquiry, getInquiriesByProperty, getAgentInquiries, getAllInquiries, getOwnerInquiries } from '../controllers/inquiryController.js';
import { protect, optionalProtect, authorize } from '../middlewares/authMiddleware.js';

const router = express.Router();

// Public route to submit inquiry (optionalProtect to grab userId if logged in)
router.post('/', optionalProtect, createInquiry);

// Protected routes to view inquiries (e.g. for agents)
router.get('/agent', protect, authorize('agent', 'company_agent', 'company'), getAgentInquiries);
router.get('/received', protect, getOwnerInquiries); // For Any User who owns a property (Buyer/Agent)
router.get('/property/:id', protect, getInquiriesByProperty);
// Admin Route
router.get('/admin', protect, authorize('admin'), getAllInquiries);

export default router;
