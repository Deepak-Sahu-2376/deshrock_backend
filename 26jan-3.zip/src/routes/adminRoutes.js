import express from 'express';
import {
    getPendingCompanies,
    getPendingAgents,
    getPendingCompanyAgents,
    approveCompany,
    rejectCompany,
    approveAgent,
    rejectAgent
} from '../controllers/adminController.js';
import { protect, authorize } from '../middlewares/authMiddleware.js';

const router = express.Router();

// Apply Security: All routes require Login AND Admin Role
router.use(protect);
router.use(authorize('admin'));

// Dashboard - Pending Lists
router.get('/dashboard/pending-approvals/companies', getPendingCompanies);
router.get('/agents/pending-approval/individual', getPendingAgents);
router.get('/agents/pending-approval/from-company', getPendingCompanyAgents);

// Approvals/Rejections - Companies
router.post('/companies/:id/approve', approveCompany);
router.post('/companies/:id/reject', rejectCompany);

// Approvals/Rejections - Agents
router.post('/agents/:id/approve', approveAgent);
router.post('/agents/:id/reject', rejectAgent);

export default router;
