import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Visit = sequelize.define('Visit', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    // The Buyer who requested the visit
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Users',
            key: 'id'
        }
    },
    // The Property to visit
    propertyId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'Properties',
            key: 'id'
        }
    },
    // The Agent assigned to show the property
    agentId: {
        type: DataTypes.INTEGER,
        allowNull: true, // Might be auto-assigned later or picked from property owner
        references: {
            model: 'Users',
            key: 'id'
        }
    },
    preferredVisitTime: {
        type: DataTypes.DATE,
        allowNull: false
    },
    status: {
        type: DataTypes.ENUM('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED'),
        defaultValue: 'PENDING'
    },
    message: {
        type: DataTypes.TEXT,
        allowNull: true
    },
    adminNotes: { // For internal use
        type: DataTypes.TEXT,
        allowNull: true
    }
}, {
    timestamps: true,
    indexes: [
        { fields: ['userId'] },
        { fields: ['agentId'] },
        { fields: ['propertyId'] },
        { fields: ['status'] },
        { fields: ['preferredVisitTime'] }
    ]
});

export default Visit;
