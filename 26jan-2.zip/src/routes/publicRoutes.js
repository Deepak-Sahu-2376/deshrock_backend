import express from 'express';
import {
    getProperties,
    getFeaturedProperties,
    getFeaturedPropertiesTop,
    getPropertyById
} from '../controllers/propertyController.js';

import { optionalProtect } from '../middlewares/authMiddleware.js';

const router = express.Router();

// Routes mounted at /api/v1/public (based on app.js plan)

router.get('/properties', getProperties);
router.get('/properties/featured', getFeaturedProperties);
router.get('/properties/featured/top', getFeaturedPropertiesTop);
router.get('/properties/:id', optionalProtect, getPropertyById);

export default router;
