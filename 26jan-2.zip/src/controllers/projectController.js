import Project from '../models/Project.js';
import CompanyProfile from '../models/CompanyProfile.js';
import Phase from '../models/Phase.js';
import Inquiry from '../models/Inquiry.js';
import { Op } from 'sequelize';
import { sendTemplateEmail } from '../services/emailService.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create a new project
export const createProject = async (req, res) => {
    try {
        console.log("Create Project Request Body:", req.body);
        console.log("Create Project Files:", req.files);

        // 1. Parse projectDTO
        let projectData;
        try {
            projectData = JSON.parse(req.body.projectDTO);
        } catch (e) {
            return res.status(400).json({ message: 'Invalid project data format' });
        }

        // 2. Validate Company
        const company = await CompanyProfile.findByPk(projectData.companyId);
        if (!company) {
            return res.status(404).json({ message: 'Company not found' });
        }

        // 3. Process Files & Build Media Array
        const mediaArray = [];

        // Check if files exist
        if (req.files && req.files['mediaFiles']) {
            const files = req.files['mediaFiles'];
            // Ensure files is an array (multer might return single object if maxCount is 1, but we used upload.fields with array on frontend)
            // Actually frontend sends multiple files with same key 'mediaFiles'. Multer handles this as array.

            // Metadata arrays (might be strings or arrays depending on count)
            // If only 1 file, req.body.mediaTypes is a string. If multiple, it's an array.
            const toArray = (val) => Array.isArray(val) ? val : [val];

            const mediaTypes = toArray(req.body.mediaTypes || []);
            const titles = toArray(req.body.titles || []);
            const categories = toArray(req.body.categories || []);
            const isPrimaryFlags = toArray(req.body.isPrimaryFlags || []);

            files.forEach((file, index) => {
                const type = mediaTypes[index] || 'OTHER';
                const fileUrl = `/uploads/documents/${file.filename}`; // Assuming uploadMiddleware saves here

                mediaArray.push({
                    type: type, // 'IMAGE', 'VIDEO'
                    url: fileUrl,
                    title: titles[index] || file.originalname,
                    category: categories[index] || 'OTHER',
                    isPrimary: isPrimaryFlags[index] === 'true'
                });
            });
        }

        // 4. Create Project Record
        const newProject = await Project.create({
            ...projectData,
            companyId: projectData.companyId,
            media: mediaArray,
            status: 'UNDER_CONSTRUCTION' // Default
        });

        // Send Email
        const projectEmailData = {
            userName: req.user.firstName,
            projectName: newProject.name,
            location: newProject.city || 'Location', // Need to ensure city exists in projectData or fetch it
            projectType: newProject.projectType || 'Residential',
            status: newProject.status,
            projectId: newProject.id,
            viewLink: `${process.env.CLIENT_URL}/projects/${newProject.id}`
        };
        sendTemplateEmail(req.user.email, 'PROJECT_ADDED', projectEmailData).catch(console.error);

        res.status(201).json({
            message: 'Project created successfully',
            project: newProject
        });

    } catch (error) {
        console.error('Error creating project:', error);
        res.status(500).json({ message: 'Server error while creating project', error: error.message });
    }
};

// Get Project by ID
export const getProjectById = async (req, res) => {
    try {
        const project = await Project.findByPk(req.params.id, {
            include: [{
                model: CompanyProfile,
                as: 'company',
                attributes: ['companyName', 'id', 'website']
            }, {
                model: Phase,
                as: 'phases'
            }]
        });

        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        const projectData = project.toJSON();
        // Transform media to match frontend expectations
        projectData.mediaFiles = (projectData.media || []).map(m => ({
            ...m,
            mediaUrl: m.url
        }));

        res.status(200).json({
            success: true,
            data: projectData
        });

    } catch (error) {
        console.error('Error fetching project:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};


// Update Project
export const updateProject = async (req, res) => {
    try {
        const project = await Project.findByPk(req.params.id);
        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        // Auth: Admin or Company Owner
        let isAuthorized = false;
        if (req.user.userType === 'admin') {
            isAuthorized = true;
        } else {
            const company = await CompanyProfile.findOne({ where: { userId: req.user.id } }); // Assuming company user
            // Or check if req.user.id equals company user id... 
            // Ideally project has companyId. We check if user owns that company.
            if (company && company.id === project.companyId) {
                isAuthorized = true;
            }
        }

        if (!isAuthorized) {
            return res.status(403).json({ message: 'Not authorized to update this project' });
        }

        // Data
        let updates = req.body;
        if (req.body.projectDTO) {
            try {
                updates = JSON.parse(req.body.projectDTO);
            } catch (e) {
                return res.status(400).json({ message: 'Invalid project data' });
            }
        }

        // Update fields
        const allowedFields = ['name', 'description', 'city', 'address', 'projectType', 'launchDate', 'status', 'approvalStatus', 'amenities'];

        Object.keys(updates).forEach(key => {
            if (allowedFields.includes(key)) {
                project[key] = updates[key];
            }
        });

        // Admin override status
        if (req.user.userType === 'admin' && updates.approvalStatus) {
            project.approvalStatus = updates.approvalStatus;
        }

        await project.save();

        res.status(200).json({ message: 'Project updated successfully', project });

    } catch (error) {
        console.error('Error updating project:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

// Delete Project
export const deleteProject = async (req, res) => {
    try {
        const project = await Project.findByPk(req.params.id);
        if (!project) {
            return res.status(404).json({ message: 'Project not found' });
        }

        // Delete associated files
        if (project.media && Array.isArray(project.media)) {
            project.media.forEach(mediaItem => {
                if (mediaItem.url) {
                    try {
                        // mediaItem.url is like '/uploads/documents/filename.ext'
                        // We need to resolve this to absolute path
                        // Assuming app root is two levels up from controllers (src/controllers -> src -> root)
                        // But wait, where is 'uploads' served from? Usually root/uploads or root/public/uploads.
                        // Based on createProject: url is `/uploads/documents/${file.filename}`
                        // And usually static serve is app.use('/uploads', express.static(path.join(__dirname, 'uploads'))); in server.js/app.js
                        // So the physical path is path.join(process.cwd(), 'uploads', 'documents', filename)

                        const relativePath = mediaItem.url;
                        // remove leading slash if present for path joining
                        const safePath = relativePath.startsWith('/') ? relativePath.substring(1) : relativePath;

                        // Construct absolute path using process.cwd() as root
                        const absolutePath = path.join(process.cwd(), safePath);

                        if (fs.existsSync(absolutePath)) {
                            fs.unlinkSync(absolutePath);
                            console.log(`Deleted file: ${absolutePath}`);
                        }
                    } catch (err) {
                        console.error(`Failed to delete file ${mediaItem.url}:`, err);
                    }
                }
            });
        }

        // Cascade delete related Inquiries (Visits are not linked to Projects)
        await Inquiry.destroy({ where: { projectId: project.id } });

        // Also check if brochure/thumbnail fields exist directly (createProject uses media array, but early versions might have columns?)
        // The Model usage in lines 90-112 implies 'media' JSON column handles everything.
        // However, if there are specific columns like 'thumbnail' or 'brochure' in the model definition, checking them is good.
        // Looking at usage: Project.create uses media array which stores type 'IMAGE' etc.
        // So cleaning the media array should be enough.

        await project.destroy();
        res.status(200).json({ message: 'Project deleted successfully' });

    } catch (error) {
        console.error('Error deleting project:', error);
        res.status(500).json({ message: 'Server error', error: error.message });
    }
};

export const getProjects = async (req, res) => {
    // Moved/Copied logic from propertyController if needed, 
    // or just export this and update routes. 
    // For now the existing getProjects is in propertyController.
    // I can stick to that or move it here later.
};
