import jwt from 'jsonwebtoken';
import db from '../models/index.js';

const protect = async (req, res, next) => {
    let token;

    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith('Bearer')
    ) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            req.user = await db.User.findByPk(decoded.id, {
                attributes: { exclude: ['password'] },
                include: [
                    { model: db.CompanyProfile, as: 'companyProfile' },
                    { model: db.AgentProfile, as: 'agentProfile' }
                ]
            });

            if (!req.user) {
                return res.status(401).json({ success: false, message: 'Not authorized, user not found' });
            }

            next();
        } catch (error) {
            console.error(error);
            res.status(401).json({ success: false, message: 'Not authorized, token failed' });
        }
    }

    if (!token) {
        res.status(401).json({ success: false, message: 'Not authorized, no token' });
    }
};

const authorize = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.userType)) {
            return res.status(403).json({ success: false, message: `User role ${req.user.userType} is not authorized` });
        }
        next();
    };
};

const optionalProtect = async (req, res, next) => {
    let token;

    if (
        req.headers.authorization &&
        req.headers.authorization.startsWith('Bearer')
    ) {
        try {
            token = req.headers.authorization.split(' ')[1];
            const decoded = jwt.verify(token, process.env.JWT_SECRET);

            req.user = await db.User.findByPk(decoded.id, {
                attributes: { exclude: ['password'] }
            });
        } catch (error) {
            console.error('Optional Auth Error:', error.message);
            // Do not fail, just don't set user
        }
    }
    next();
};

export { protect, authorize, optionalProtect };
