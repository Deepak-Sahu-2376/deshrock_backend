import nodemailer from 'nodemailer';
import dotenv from 'dotenv';
dotenv.config();

const transporter = nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    secure: process.env.SMTP_PORT == 465, // true for 465, false for 587
    auth: {
        user: process.env.SMTP_USER,
        pass: process.env.SMTP_PASS,
    },
});

console.log('Email Service Configured:', {
    host: process.env.SMTP_HOST,
    port: process.env.SMTP_PORT,
    user: process.env.SMTP_USER,
    secure: process.env.SMTP_PORT == 465
});

import { EMAIL_TEMPLATES } from '../utils/emailTemplates.js';

const sendEmail = async (to, subject, text, html) => {
    console.log(`Preparing to send email to: ${to}`);
    const mailOptions = {
        from: process.env.EMAIL_FROM || process.env.SMTP_USER,
        to,
        subject,
        text,
        html,
    };

    try {
        const info = await transporter.sendMail(mailOptions);
        console.log('Email sent: ' + info.response);
        return true;
    } catch (error) {
        console.error('Error sending email:', error);
        return false;
    }
};

export const sendTemplateEmail = async (to, templateType, data) => {
    const template = EMAIL_TEMPLATES[templateType];
    if (!template) {
        console.error(`Email template type '${templateType}' not found.`);
        return false;
    }

    const { subject, html, text } = template(data);
    return await sendEmail(to, subject, text, html);
};

export default sendEmail;
