import db from '../models/index.js';
import sendEmail from '../services/emailService.js';
import { Op } from 'sequelize';

// @desc    Send OTP for Agent Reg
// @route   POST /api/v1/agents/register/send-otp
const sendAgentOtp = async (req, res) => {
    const email = req.query.email || req.body.email;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    try {
        const userExists = await db.User.findOne({ where: { email } });
        if (userExists) return res.status(400).json({ success: false, message: 'Email already registered' });

        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await db.Otp.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'agent_registration'
        });

        await sendEmail(email, 'Agent Registration OTP', `Your OTP is ${otpCode}`);
        res.json({ success: true, message: 'OTP sent to agent email.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Register Agent
// @route   POST /api/v1/agents/register
const registerAgent = async (req, res) => {
    const {
        firstName, lastName, email, phone, password, otpCode,
        city, state, country, address, pincode,
        specialization, experienceYears, bio, serviceAreas, languages,
        dob,
        agentType, companyId, companyName,
        allowMarketingEmails, allowSmsNotifications, profileVisibility,
        acceptTerms, acceptPrivacyPolicy
    } = req.body;

    console.log('Register Agent Request Body:', req.body);
    console.log('Register Agent Request Files:', req.files);

    try {
        const otp = await db.Otp.findOne({
            where: {
                identifier: email,
                code: otpCode,
                isUsed: false,
                purpose: 'agent_registration',
                expiresAt: { [Op.gt]: new Date() }
            }
        });

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        // Validate Company if Company Agent
        if (agentType === 'COMPANY_AGENT') {
            if (!companyId) {
                return res.status(400).json({ success: false, message: 'Company selection is required for Company Agents' });
            }

            const companyProfile = await db.CompanyProfile.findOne({
                where: {
                    id: companyId,
                    status: 'approved'
                }
            });

            if (!companyProfile) {
                return res.status(400).json({ success: false, message: 'Invalid or unapproved company selected' });
            }
        }

        // Create User
        // agentType logic: If COMPANY_AGENT, userType could be 'company_agent' or just 'agent'. 
        // Docs say userType is checked. Let's stick to 'agent'.
        const newUser = await db.User.create({
            identifier: email,
            email,
            firstName,
            lastName,
            password,
            phone,
            userType: agentType === 'COMPANY_AGENT' ? 'company_agent' : 'agent',
            isVerified: true,
            acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications
        });

        // Create Agent Profile
        await db.AgentProfile.create({
            userId: newUser.id,
            city, state, country, address, pincode,
            specialization, experienceYears, bio, serviceAreas, languages,
            dob,
            agentType, companyId, companyName,
            profileVisibility,
            status: agentType === 'COMPANY_AGENT' ? 'pending_company_approval' : 'pending'
        });

        // Save Documents if any
        if (req.files && req.files.length > 0) {
            const documentPromises = req.files.map(file => {
                return db.Document.create({
                    entityId: newUser.id, // Linked to User
                    entityType: 'AGENT',
                    documentType: 'registration_document',
                    fileName: file.originalname,
                    fileUrl: `/uploads/documents/${file.filename}`,
                    mimeType: file.mimetype,
                    fileSize: file.size,
                    status: 'PENDING'
                });
            });
            await Promise.all(documentPromises);
        }

        otp.isUsed = true;
        await otp.save();

        res.status(201).json({ success: true, message: 'Agent registered successfully. Pending approval.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get All Agents (Admin)
// @route   GET /api/v1/agents
const getAllAgents = async (req, res) => {
    try {
        const agents = await db.AgentProfile.findAll({
            include: [{
                model: db.User,
                as: 'user',
                attributes: ['email', 'firstName', 'lastName', 'phone', 'isVerified']
            }],
            order: [['createdAt', 'DESC']]
        });

        res.status(200).json({
            success: true,
            data: agents
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

export { sendAgentOtp, registerAgent, getAllAgents };
