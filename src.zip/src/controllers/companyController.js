import db from '../models/index.js';
import { sendTemplateEmail } from '../services/emailService.js';
import { Op } from 'sequelize';

// @desc    Send OTP for Company Registration
// @route   POST /api/v1/companies/register/send-otp
const sendCompanyOtp = async (req, res) => {
    const email = req.query.email || req.body.email;
    if (!email) return res.status(400).json({ success: false, message: 'Email is required' });

    try {
        const userExists = await db.User.findOne({ where: { email } });
        if (userExists) return res.status(400).json({ success: false, message: 'Email already registered' });

        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await db.Otp.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'company_registration'
        });

        const otpData = {
            userName: 'User', // We don't have name yet in send-otp phase usually
            otp: otpCode
        };
        await sendTemplateEmail(email, 'OTP_LOGIN', otpData);

        res.json({ success: true, message: 'OTP sent to company email.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Register Company (Verify OTP & Create)
// @route   POST /api/v1/companies/register
const registerCompany = async (req, res) => {
    const {
        email, otpCode, password, confirmPassword,
        companyName, companyType, registrationNumber, establishmentYear,
        contactPersonName, contactPersonDesignation, phone, alternateEmail,
        address, city, state, country, pincode,
        description, serviceAreas, specializations,
        gstNumber, panNumber, licenseNumber, licenseAuthority, licenseExpiryDate,
        website, employeeCount,
        acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications
    } = req.body;

    if (password !== confirmPassword) return res.status(400).json({ success: false, message: 'Passwords do not match' });

    try {
        // Verify OTP
        const otp = await db.Otp.findOne({
            where: {
                identifier: email,
                code: otpCode,
                isUsed: false,
                purpose: 'company_registration',
                expiresAt: { [Op.gt]: new Date() }
            }
        });

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        // Create User
        const newUser = await db.User.create({
            identifier: email,
            email,
            firstName: contactPersonName.split(' ')[0] || 'Company', // Extract First Name fallback
            lastName: contactPersonName.split(' ').slice(1).join(' ') || 'Admin', // Extract Last Name fallback
            password,
            phone,
            userType: 'company',
            isVerified: true,
            acceptTerms, acceptPrivacyPolicy, allowMarketingEmails, allowSmsNotifications
        });

        // Create Company Profile
        await db.CompanyProfile.create({
            userId: newUser.id,
            companyName, companyType, registrationNumber, establishmentYear,
            contactPersonName, contactPersonDesignation, alternateEmail,
            address, city, state, country, pincode,
            description, serviceAreas, specializations,
            gstNumber, panNumber, licenseNumber, licenseAuthority, licenseExpiryDate,
            website, employeeCount,
            status: 'pending'
        });

        // Save Documents if any
        if (req.files && req.files.length > 0) {
            const documentPromises = req.files.map(file => {
                return db.Document.create({
                    entityId: newUser.id, // Linked to User (since Agent/Company Profiles are 1:1 with User)
                    entityType: 'COMPANY',
                    documentType: 'registration_document', // Default or parse from fieldname
                    fileName: file.originalname,
                    fileUrl: `/uploads/documents/${file.filename}`,
                    mimeType: file.mimetype,
                    fileSize: file.size,
                    status: 'PENDING'
                });
            });
            await Promise.all(documentPromises);
        }

        otp.isUsed = true;
        await otp.save();

        // Send Registration Submitted Email
        const regData = {
            userName: newUser.firstName,
            companyName: companyName
        };
        sendTemplateEmail(email, 'COMPANY_REGISTRATION_SUBMITTED', regData).catch(console.error);

        res.status(201).json({ success: true, message: 'Company registered successfully. Pending approval.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Companies Dropdown
// @route   GET /api/v1/companies/dropdown
const getCompaniesDropdown = async (req, res) => {
    try {
        console.log("Fetching companies dropdown...");
        const companies = await db.CompanyProfile.findAll({
            attributes: ['id', 'companyName', 'status'], // Added status to debug
            where: { status: 'approved' }, // Only approved companies
            logging: console.log // Log the SQL query
        });
        console.log("Companies found (backend):", companies.length);
        if (companies.length === 0) {
            // Debug: check if any companies exist at all
            const allCompanies = await db.CompanyProfile.findAll({ attributes: ['id', 'companyName', 'status'] });
            console.log("All companies in DB:", allCompanies.map(c => c.get({ plain: true })));
        }
        res.json({ success: true, data: companies });
    } catch (error) {
        console.error("Error fetching companies dropdown:", error);
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Verified Companies Count
// @route   GET /api/v1/companies/statistics/verified
const getVerifiedCompaniesCount = async (req, res) => {
    try {
        const count = await db.CompanyProfile.count({
            where: { status: 'approved' }
        });
        res.json({ verified: count });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Pending Companies Count
// @route   GET /api/v1/companies/statistics/pending
const getPendingCompaniesCount = async (req, res) => {
    try {
        const count = await db.CompanyProfile.count({
            where: { status: 'pending' }
        });
        res.json({ pending: count });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get All Companies (Admin)
// @route   GET /api/v1/companies
const getAllCompanies = async (req, res) => {
    try {
        const companies = await db.CompanyProfile.findAll({
            include: [{
                model: db.User,
                as: 'user', // Ensure this alias matches your model association
                attributes: ['email', 'phone']
            }],
            order: [['createdAt', 'DESC']]
        });

        // Flatten the structure for the frontend
        const flatCompanies = companies.map(company => {
            const plainCompany = company.get({ plain: true });
            return {
                ...plainCompany,
                email: plainCompany.user?.email, // Flatten email
                phone: plainCompany.user?.phone  // Flatten phone
            };
        });

        res.status(200).json({
            success: true,
            data: flatCompanies
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Agent Requests for Company
// @route   GET /api/v1/companies/agent-requests
const getAgentRequests = async (req, res) => {
    try {
        const userId = req.user.id;
        const companyProfile = await db.CompanyProfile.findOne({ where: { userId } });

        if (!companyProfile) {
            return res.status(404).json({ success: false, message: 'Company profile not found' });
        }

        const agentRequests = await db.AgentProfile.findAll({
            where: {
                companyId: companyProfile.id,
                status: 'pending_company_approval'
            },
            include: [{
                model: db.User,
                as: 'user',
                attributes: ['firstName', 'lastName', 'email', 'phone']
            }]
        });

        // Flatten
        const flatRequests = agentRequests.map(agent => ({
            id: agent.id,
            ...agent.get({ plain: true }),
            firstName: agent.user?.firstName,
            lastName: agent.user?.lastName,
            email: agent.user?.email,
            phone: agent.user?.phone
        }));

        res.json({ success: true, data: flatRequests });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Approve Agent Request
// @route   POST /api/v1/companies/agent-requests/:id/approve
const approveAgentRequest = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        const companyProfile = await db.CompanyProfile.findOne({ where: { userId } });

        if (!companyProfile) return res.status(404).json({ success: false, message: 'Company not found' });

        const agent = await db.AgentProfile.findOne({
            where: {
                id,
                companyId: companyProfile.id,
                status: 'pending_company_approval'
            }
        });

        if (!agent) return res.status(404).json({ success: false, message: 'Request not found' });

        agent.status = 'pending'; // Move to Admin Queue
        await agent.save();

        res.json({ success: true, message: 'Agent approved. Now pending Admin approval.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Reject Agent Request
// @route   POST /api/v1/companies/agent-requests/:id/reject
const rejectAgentRequest = async (req, res) => {
    try {
        const { id } = req.params;
        const userId = req.user.id;
        const companyProfile = await db.CompanyProfile.findOne({ where: { userId } });

        if (!companyProfile) return res.status(404).json({ success: false, message: 'Company not found' });

        const agent = await db.AgentProfile.findOne({
            where: {
                id,
                companyId: companyProfile.id,
                status: 'pending_company_approval'
            }
        });

        if (!agent) return res.status(404).json({ success: false, message: 'Request not found' });

        agent.status = 'rejected';
        await agent.save();

        res.json({ success: true, message: 'Agent request rejected.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Active Agents for Company
// @route   GET /api/v1/companies/agents
const getCompanyAgents = async (req, res) => {
    try {
        const userId = req.user.id;
        const companyProfile = await db.CompanyProfile.findOne({ where: { userId } });

        if (!companyProfile) return res.status(404).json({ success: false, message: 'Company not found' });

        const agents = await db.AgentProfile.findAll({
            where: {
                companyId: companyProfile.id,
                status: 'approved'
            },
            include: [{
                model: db.User,
                as: 'user',
                attributes: ['firstName', 'lastName', 'email', 'phone']
            }]
        });

        const flatAgents = agents.map(agent => ({
            id: agent.id,
            ...agent.get({ plain: true }),
            firstName: agent.user?.firstName,
            lastName: agent.user?.lastName,
            email: agent.user?.email,
            phone: agent.user?.phone
        }));

        res.json({ success: true, data: flatAgents });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Get Company Dashboard Stats
// @route   GET /api/v1/companies/statistics/dashboard
const getDashboardStats = async (req, res) => {
    try {
        let companyId;

        if (req.user.userType === 'company') {
            const company = await db.CompanyProfile.findOne({ where: { userId: req.user.id } });
            if (!company) return res.status(404).json({ success: false, message: 'Company not found' });
            companyId = company.id;
        } else if (req.user.userType === 'company_agent') {
            const agent = await db.AgentProfile.findOne({ where: { userId: req.user.id } });
            if (!agent) return res.status(404).json({ success: false, message: 'Agent not found' });
            companyId = agent.companyId;
        } else {
            return res.status(403).json({ success: false, message: 'Not authorized' });
        }

        const totalProjects = await db.Project.count({ where: { companyId } });

        const totalAgents = await db.AgentProfile.count({
            where: { companyId, status: 'approved' }
        });

        const activeListings = await db.Property.count({
            where: { companyId, status: 'APPROVED' }
        });

        const pendingAgents = await db.AgentProfile.count({
            where: { companyId, status: 'pending_company_approval' }
        });

        // Sum viewCount
        const totalViews = await db.Property.sum('viewCount', {
            where: { companyId }
        }) || 0;

        console.log('Dashboard Stats Debug:', {
            companyId,
            userType: req.user.userType,
            totalProjects,
            totalAgents,
            activeListings,
            pendingAgents,
            totalViews
        });

        res.json({
            success: true,
            data: {
                totalProjects,
                totalAgents,
                activeListings,
                pendingAgents,
                totalViews,
                totalLeads: 0 // Placeholder
            }
        });

    } catch (error) {
        console.error('Error fetching dashboard stats:', error);
        res.status(500).json({ success: false, message: error.message });
    }
};

export {
    sendCompanyOtp,
    registerCompany,
    getCompaniesDropdown,
    getVerifiedCompaniesCount,
    getPendingCompaniesCount,
    getAllCompanies,
    getAgentRequests,
    approveAgentRequest,
    rejectAgentRequest,
    getCompanyAgents,
    getDashboardStats
};
