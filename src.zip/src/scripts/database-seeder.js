import db from '../models/index.js';
import seedAdmin from './adminSeeder.js';
import dotenv from 'dotenv';

dotenv.config();

const runSeeder = async () => {
    console.log('Starting Database Seeder...');
    try {
        await db.sequelize.authenticate();

        // Ensure tables exist before seeding
        await db.sequelize.sync({ alter: true });

        // Run Admin Seeder
        await seedAdmin();

        console.log('Seeding completed successfully.');
        process.exit(0);
    } catch (error) {
        console.error('Error running seeder:', error);
        process.exit(1);
    }
};

runSeeder();
