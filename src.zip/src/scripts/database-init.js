import pg from 'pg';
import { Sequelize } from 'sequelize';
import dotenv from 'dotenv';
import db from '../models/index.js';

dotenv.config();

const { Client } = pg;

const initializeDatabase = async () => {
    const dbUrl = process.env.DATABASE_URL;
    if (!dbUrl) {
        console.error('DATABASE_URL is not defined in .env');
        process.exit(1);
    }

    // Parse DB Name from URL
    // Format: postgresql://user:pass@host:port/dbname
    const dbName = dbUrl.split('/').pop();
    const connectionStringWithoutDb = dbUrl.substring(0, dbUrl.lastIndexOf('/'));

    // 1. Create Database if not exists
    console.log(`Checking if database '${dbName}' exists...`);
    const client = new Client({ connectionString: connectionStringWithoutDb + '/postgres' }); // Connect to default 'postgres' db

    try {
        await client.connect();
        const res = await client.query(`SELECT 1 FROM pg_database WHERE datname = $1`, [dbName]);

        if (res.rowCount === 0) {
            console.log(`Database '${dbName}' does not exist. Creating...`);
            await client.query(`CREATE DATABASE "${dbName}"`);
            console.log(`Database '${dbName}' created successfully.`);
        } else {
            console.log(`Database '${dbName}' already exists.`);
        }
    } catch (error) {
        console.error('Error checking/creating database:', error);
        process.exit(1);
    } finally {
        await client.end();
    }

    // 2. Sync Tables
    console.log('Syncing database tables...');

    // Log models that will be synced
    const models = Object.keys(db).filter(key => key !== 'sequelize' && key !== 'Sequelize');
    console.log('Models to be synced:', models);

    try {
        await db.sequelize.authenticate();
        // Force: false ensures we don't drop tables, alter: true updates schema
        await db.sequelize.sync({ alter: true });
        console.log('Database tables synced successfully.');
        process.exit(0);
    } catch (error) {
        console.error('Error syncing tables:', error);
        process.exit(1);
    }
};

initializeDatabase();
