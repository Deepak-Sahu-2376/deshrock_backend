import express from 'express';
import { sendAgentOtp, registerAgent, getAllAgents } from '../controllers/agentController.js';
import { protect, authorize } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

const router = express.Router();

router.post('/register/send-otp', sendAgentOtp);
router.post('/register', upload.array('documents'), registerAgent);
router.get('/', protect, authorize('admin'), getAllAgents);

export default router;
