import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Inquiry = sequelize.define('Inquiry', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    propertyId: {
        type: DataTypes.INTEGER,
        allowNull: true,
        references: {
            model: 'Properties',
            key: 'id'
        }
    },
    projectId: {
        type: DataTypes.UUID,
        allowNull: true,
        references: {
            model: 'Projects',
            key: 'id'
        }
    },
    userId: { // If the user is logged in
        type: DataTypes.INTEGER,
        allowNull: true
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    email: {
        type: DataTypes.STRING,
        allowNull: false
    },
    phone: {
        type: DataTypes.STRING,
        allowNull: false
    },
    message: {
        type: DataTypes.TEXT,
        allowNull: false
    },
    status: {
        type: DataTypes.ENUM('PENDING', 'CONTACTED', 'RESOLVED', 'SPAM'),
        defaultValue: 'PENDING'
    }
}, {
    timestamps: true
});

export default Inquiry;
