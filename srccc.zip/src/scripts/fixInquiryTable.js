import sequelize from '../config/database.js';

const fixTable = async () => {
    try {
        await sequelize.authenticate();
        console.log('Database connected.');

        // Drop the table to allow clean recreation
        await sequelize.getQueryInterface().dropTable('Inquiries');
        console.log('Inquiries table dropped successfully.');

        process.exit(0);
    } catch (error) {
        console.error('Error fixing table:', error);
        process.exit(1);
    }
};

fixTable();
