import app from './src/app.js';
import db from './src/models/index.js';
import dotenv from 'dotenv';
import seedAdmin from './src/scripts/adminSeeder.js';

dotenv.config();

const PORT = process.env.PORT || 8080;

const startServer = async () => {
    try {
        await db.sequelize.authenticate();
        console.log('Database connected successfully.');

        // Sync models
        await db.sequelize.sync({ alter: true });
        console.log('Database synced.');

        // Run Seeder
        await seedAdmin(); // Create Admin

        app.listen(PORT, () => {
            console.log(`Server is running on port ${PORT}`);
        });
    } catch (error) {
        console.error('Unable to start server:', error);
    }
};

startServer();
