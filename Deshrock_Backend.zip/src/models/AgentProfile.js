import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const AgentProfile = sequelize.define('AgentProfile', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        unique: true
    },
    city: { type: DataTypes.STRING, allowNull: true },
    state: { type: DataTypes.STRING, allowNull: true },
    country: { type: DataTypes.STRING, allowNull: true },
    address: { type: DataTypes.TEXT, allowNull: true },
    pincode: { type: DataTypes.STRING, allowNull: true },

    specialization: { type: DataTypes.STRING, allowNull: true },
    experienceYears: { type: DataTypes.FLOAT, defaultValue: 0 },
    bio: { type: DataTypes.TEXT, allowNull: true },
    serviceAreas: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },
    languages: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },

    // License
    licenseNumber: { type: DataTypes.STRING, allowNull: true },
    licenseState: { type: DataTypes.STRING, allowNull: true },
    licenseExpiryDate: { type: DataTypes.DATEONLY, allowNull: true },

    // Association
    agentType: { type: DataTypes.ENUM('INDIVIDUAL', 'COMPANY_AGENT'), defaultValue: 'INDIVIDUAL' },
    companyId: { type: DataTypes.INTEGER, allowNull: true }, // Link to a CompanyProfile ID
    companyName: { type: DataTypes.STRING, allowNull: true }, // Fallback text?

    profileVisibility: { type: DataTypes.BOOLEAN, defaultValue: true },

    status: {
        type: DataTypes.ENUM('pending', 'pending_company_approval', 'approved', 'rejected'),
        defaultValue: 'pending'
    }
}, {
    timestamps: true
});

export default AgentProfile;
