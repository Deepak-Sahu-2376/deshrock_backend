const API_URL = 'http://localhost:8080/api/v1';

async function verifyPhases() {
    console.log('1. Fetching Projects...');
    try {
        const projectsRes = await fetch(`${API_URL}/properties/projects`);
        if (!projectsRes.ok) throw new Error(`Failed to fetch projects: ${projectsRes.status} ${projectsRes.statusText}`);
        const projectsData = await projectsRes.json();

        // Response structure is { success: true, data: { content: [...], projects: [...] } }
        const projects = projectsData.data?.content || projectsData.data?.projects || [];

        if (!projects || projects.length === 0) {
            console.error('No projects found. Cannot verify phases.');
            return;
        }

        const projectId = projects[0].id;
        console.log(`Using Project ID: ${projectId}`);

        // Create a new Phase
        console.log('\n2. Creating a new Phase...');
        const phasePayload = {
            name: `Phase Verification ${Date.now()}`,
            phaseNumber: 1,
            status: 'UNDER_CONSTRUCTION',
            description: 'Verification phase description',
            totalUnits: 100,
            launchedDate: new Date().toISOString(),
            completionDate: new Date(Date.now() + 31536000000).toISOString(),
            reraNumber: `RERA-VERIFY-${Date.now()}`
        };

        const createRes = await fetch(`${API_URL}/properties/projects/${projectId}/phases`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(phasePayload)
        });

        if (!createRes.ok) {
            const errText = await createRes.text();
            console.log(`Creation failed: ${createRes.status} ${errText}`);
        } else {
            const createData = await createRes.json();
            console.log('Phase Created:', createData);
        }

        // Verify Fetching Project includes Phases
        console.log('\n3. Fetching Project Details to verify phases are included...');
        const projectDetailRes = await fetch(`${API_URL}/properties/projects/${projectId}`);
        if (!projectDetailRes.ok) throw new Error(`Failed to fetch project details: ${projectDetailRes.statusText}`);

        const projectDetailData = await projectDetailRes.json();
        const project = projectDetailData.data || projectDetailData; // adjust based on API structure

        if (project.phases && Array.isArray(project.phases)) {
            console.log(`Success! Project has ${project.phases.length} phases.`);
            console.log('Phases:', JSON.stringify(project.phases, null, 2));
        } else {
            console.error('Failed: Project does not contain "phases" array.');
            console.log('Project keys:', Object.keys(project));
        }

    } catch (error) {
        console.error('Verification Error:', error);
    }
}

verifyPhases();
