import db from './src/models/index.js';
import dotenv from 'dotenv';
dotenv.config();

const debugQuery = async () => {
    try {
        await db.sequelize.authenticate();
        console.log('Database connected.');

        const userId = 3; // The Company User ID
        console.log(`Querying for userId: ${userId}`);

        const companyProfile = await db.CompanyProfile.findOne({ where: { userId } });
        console.log('Company Profile:', companyProfile ? companyProfile.toJSON() : 'Not Found');

        if (companyProfile) {
            const agents = await db.AgentProfile.findAll({
                where: {
                    companyId: companyProfile.id,
                    status: 'pending_company_approval'
                },
                include: [{
                    model: db.User,
                    as: 'user',
                    attributes: ['firstName', 'lastName', 'email', 'phone']
                }],
                logging: console.log // Log the SQL query
            });

            console.log(`Found ${agents.length} matching agents.`);
            agents.forEach(a => console.log(a.toJSON()));
        }

    } catch (error) {
        console.error('Error:', error);
    } finally {
        await db.sequelize.close();
    }
};

debugQuery();
