import db from '../models/index.js';
import bcrypt from 'bcryptjs';

const seedAdmin = async () => {
    try {
        const adminEmail = 'deshrockpvt.ltd@gmail.com';
        const existingAdmin = await db.User.findOne({ where: { email: adminEmail } });

        if (existingAdmin) {
            console.log('Admin user already exists.');
            return;
        }

        // Create Admin
        // Password hashing is handled by the model hook, so just pass the plain password
        await db.User.create({
            identifier: adminEmail,
            email: adminEmail,
            firstName: 'Super',
            lastName: 'Admin',
            password: 'Suraj@11', // Will be hashed
            userType: 'admin',
            isVerified: true
        });

        console.log('Admin user created successfully.');
    } catch (error) {
        console.error('Error seeding admin:', error);
    }
};

export default seedAdmin;
