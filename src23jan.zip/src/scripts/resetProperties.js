
import db from '../models/index.js';

const resetTables = async () => {
    try {
        await db.sequelize.authenticate();
        console.log('Database connected.');

        // Drop Inquiries first
        await db.sequelize.query('DROP TABLE IF EXISTS "Inquiries" CASCADE;');
        console.log('Dropped Inquiries table.');

        // Drop Visits
        await db.sequelize.query('DROP TABLE IF EXISTS "Visits" CASCADE;');
        console.log('Dropped Visits table.');

        // Drop Properties
        await db.sequelize.query('DROP TABLE IF EXISTS "Properties" CASCADE;');
        console.log('Dropped Properties table.');

        // We rely on the main server restart to sync/create them again
        // or we can call sync here.
        await db.sequelize.sync({ alter: true });
        console.log('Tables recreated.');

        process.exit(0);
    } catch (error) {
        console.error('Error resetting tables:', error);
        process.exit(1);
    }
};

resetTables();
