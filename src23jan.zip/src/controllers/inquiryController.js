import db from '../models/index.js';
import sendEmail from '../services/emailService.js';

// @desc    Create new inquiry
// @route   POST /api/v1/inquiries
const createInquiry = async (req, res) => {
    try {
        let { propertyId, name, email, phone, message, projectId } = req.body;
        const userId = req.user ? req.user.id : null;

        if ((!propertyId && !projectId) || !name || !email || !phone || !message) {
            return res.status(400).json({ success: false, message: 'All fields are required (propertyId or projectId)' });
        }

        let targetEntity = null;
        let type = '';

        if (propertyId) {
            type = 'Property';
            targetEntity = await db.Property.findByPk(propertyId, {
                include: [
                    { model: db.User, as: 'user', attributes: ['email', 'firstName', 'lastName'] },
                    {
                        model: db.CompanyProfile,
                        as: 'company',
                        attributes: ['companyName'],
                        include: [{ model: db.User, as: 'user', attributes: ['email'] }]
                    }
                ]
            });
        } else if (projectId) {
            type = 'Project';
            targetEntity = await db.Project.findByPk(projectId, {
                include: [
                    {
                        model: db.CompanyProfile,
                        as: 'company',
                        attributes: ['companyName'],
                        include: [{ model: db.User, as: 'user', attributes: ['email'] }]
                    },
                ]
            });
        }

        if (!targetEntity) {
            return res.status(404).json({ success: false, message: `${type} not found` });
        }

        const inquiry = await db.Inquiry.create({
            propertyId: propertyId || null,
            projectId: projectId || null,
            userId,
            name,
            email,
            phone,
            message
        });

        // Send Email Notification to Owner
        let recipientEmail = null;
        let recipientName = 'Agent';
        const title = targetEntity.title || targetEntity.name; // Property has title, Project has name

        if (type === 'Property') {
            if (targetEntity.user) {
                recipientEmail = targetEntity.user.email;
                recipientName = targetEntity.user.firstName;
            } else if (targetEntity.company && targetEntity.company.user) {
                recipientEmail = targetEntity.company.user.email;
                recipientName = targetEntity.company.companyName;
            }
        } else if (type === 'Project') {
            if (targetEntity.company && targetEntity.company.user) {
                recipientEmail = targetEntity.company.user.email;
                recipientName = targetEntity.company.companyName;
            }
        }

        if (recipientEmail) {
            const emailSubject = `New Inquiry for: ${title}`;
            const link = type === 'Property'
                ? `${process.env.CLIENT_URL}/property/${targetEntity.id}`
                : `${process.env.CLIENT_URL}/projects/${targetEntity.id}`; // Assuming project URL

            const emailHtml = `
                <h3>New ${type} Inquiry</h3>
                <p><strong>${type}:</strong> ${title}</p>
                <p><strong>Available at:</strong> <a href="${link}">View ${type}</a></p>
                <hr />
                <h4>Lead Details:</h4>
                <p><strong>Name:</strong> ${name}</p>
                <p><strong>Email:</strong> ${email}</p>
                <p><strong>Phone:</strong> ${phone}</p>
                <p><strong>Message:</strong></p>
                <blockquote style="background: #f9f9f9; padding: 10px; border-left: 5px solid #ccc;">${message}</blockquote>
            `;
            // Non-blocking email send
            sendEmail(recipientEmail, emailSubject, `New inquiry from ${name} for ${title}`, emailHtml);
        }

        res.status(201).json({
            success: true,
            message: 'Inquiry submitted successfully',
            data: inquiry
        });

    } catch (error) {
        console.error('Error creating inquiry:', error);
        res.status(500).json({ success: false, message: error.message || 'Internal Server Error' });
    }
};

// @desc    Get Inquiries for a specific property (Protected)
// @route   GET /api/v1/inquiries/property/:id
const getInquiriesByProperty = async (req, res) => {
    try {
        const propertyId = req.params.id;

        const inquiries = await db.Inquiry.findAll({
            where: { propertyId },
            order: [['createdAt', 'DESC']]
        });

        res.status(200).json({
            success: true,
            data: inquiries
        });
    } catch (error) {
        console.error('Error fetching inquiries:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

// @desc    Get All Inquiries for Agent (Protected)
// @route   GET /api/v1/inquiries/agent
const getAgentInquiries = async (req, res) => {
    try {
        const agentId = req.user.id;

        let propertyWhere = {};

        if (req.user.userType === 'company') {
            // Company Admin sees all properties associated with their company
            if (req.user.companyProfile && req.user.companyProfile.id) {
                propertyWhere = { companyId: req.user.companyProfile.id };
            } else {
                // Fallback if company profile is missing in request (should be populated by authMiddleware)
                return res.status(403).json({ success: false, message: 'Company Profile not found' });
            }
        } else {
            // Agents (Individual or Company Agent) see only their own properties
            propertyWhere = { userId: req.user.id };
        }

        // Find inquiries for matching properties
        const inquiries = await db.Inquiry.findAll({
            include: [
                {
                    model: db.Property,
                    as: 'property',
                    where: propertyWhere,
                    attributes: ['id', 'title'],
                    include: [
                        {
                            model: db.User,
                            as: 'user',
                            attributes: ['firstName', 'lastName', 'email', 'phone']
                        }
                    ]
                }
            ],
            order: [['createdAt', 'DESC']]
        });

        res.status(200).json({
            success: true,
            count: inquiries.length,
            data: inquiries
        });

    } catch (error) {
        console.error('Error fetching agent inquiries:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

// @desc    Get All Inquiries (Admin) - Paginated
// @route   GET /api/v1/inquiries/admin
const getAllInquiries = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const { sort } = req.query; // e.g. "createdAt,desc"

        let order = [['createdAt', 'DESC']];
        if (sort) {
            const [field, direction] = sort.split(',');
            if (field && direction) {
                order = [[field, direction.toUpperCase()]];
            }
        }

        const { count, rows } = await db.Inquiry.findAndCountAll({
            include: [
                {
                    model: db.Property,
                    as: 'property',
                    attributes: ['id', 'title']
                },
                {
                    model: db.Project,
                    as: 'project',
                    attributes: ['id', 'name']
                }
            ],
            limit: size,
            offset: page * size,
            order: order
        });

        res.status(200).json({
            success: true,
            content: rows,
            totalPages: Math.ceil(count / size),
            totalElements: count,
            number: page,
            size: size
        });

    } catch (error) {
        console.error('Error fetching all inquiries:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
};

export {
    createInquiry,
    getInquiriesByProperty,
    getAgentInquiries,
    getAllInquiries
};
