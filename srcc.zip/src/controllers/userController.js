import db from '../models/index.js';

// @desc    Get current logged in user
// @route   GET /api/v1/users/me
// @access  Private
const getMe = async (req, res) => {
    res.set('Cache-Control', 'no-store');
    try {
        const user = await db.User.findByPk(req.user.id, {
            attributes: { exclude: ['password'] }
        });

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        // Compute derived fields
        const userData = user.toJSON();

        // Full Name
        userData.fullName = `${user.firstName} ${user.lastName}`;

        // Initials
        userData.initials = (user.firstName[0] + user.lastName[0]).toUpperCase();

        // Profile Image Map
        userData.profileImageUrl = user.avatar;

        // Account Age
        const createdDate = new Date(user.createdAt);
        const now = new Date();
        const diffTime = Math.abs(now - createdDate);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays > 365) {
            const years = Math.floor(diffDays / 365);
            userData.accountAge = `${years} year${years > 1 ? 's' : ''}`;
        } else if (diffDays > 30) {
            const months = Math.floor(diffDays / 30);
            userData.accountAge = `${months} month${months > 1 ? 's' : ''}`;
        } else {
            userData.accountAge = `${diffDays} day${diffDays !== 1 ? 's' : ''}`;
        }

        // Default/Mock fields for now (can be added to DB later)
        userData.timezone = userData.timezone || 'IST (UTC+05:30)';
        userData.language = userData.language || 'English';
        userData.verificationLevel = user.isVerified ? 'Verified' : 'Basic';
        userData.verificationBadge = user.isVerified ? 'Identity Verified' : 'Pending Verification';
        userData.statusBadge = 'Active';
        userData.profileCompletionPercentage = user.profileComplete ? 100 : 60;
        userData.locationString = 'India';
        userData.rolesList = user.userType.charAt(0).toUpperCase() + user.userType.slice(1);
        userData.loginCount = 1; // Mock value

        // Verification Statuses
        userData.isEmailVerified = true; // Assume true for logged in users for now
        userData.isPhoneVerified = !!user.phone; // Assume verified if phone exists for now

        // Date formatting
        userData.lastLoginAt = new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); // Mock for now
        userData.createdAt = new Date(user.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });

        res.status(200).json({
            success: true,
            data: userData
        });
    } catch (error) {
        console.error('Error fetching user profile:', error);
        res.status(500).json({
            success: false,
            message: 'Server Error'
        });
    }
};

const uploadAvatar = async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                success: false,
                message: 'No file uploaded'
            });
        }

        // Construct file URL (Relative path)
        const fileUrl = `/uploads/documents/${req.file.filename}`;

        // Update user avatar in DB
        const user = await db.User.findByPk(req.user.id);
        if (user) {
            user.avatar = fileUrl;
            await user.save();
        }

        res.status(200).json({
            success: true,
            message: 'Avatar uploaded successfully',
            data: {
                profileImageUrl: fileUrl,
                imageUrl: fileUrl,
                user: {
                    ...user.toJSON(),
                    profileImageUrl: fileUrl
                }
            }
        });

    } catch (error) {
        console.error('Error uploading avatar:', error);
        res.status(500).json({
            success: false,
            message: 'Server Error during upload'
        });
    }
};

const deleteAvatar = async (req, res) => {
    try {
        const user = await db.User.findByPk(req.user.id);

        if (!user) {
            return res.status(404).json({
                success: false,
                message: 'User not found'
            });
        }

        user.avatar = null;
        await user.save();

        res.status(200).json({
            success: true,
            message: 'Avatar removed successfully',
            data: {
                profileImageUrl: null,
                user: {
                    ...user.toJSON(),
                    profileImageUrl: null
                }
            }
        });

    } catch (error) {
        console.error('Error deleting avatar:', error);
        res.status(500).json({
            success: false,
            message: 'Server Error during deletion'
        });
    }
};

export {
    getMe,
    uploadAvatar,
    deleteAvatar
};
