import db from '../models/index.js';

// @desc    Get pending company requests
// @route   GET /api/v1/admin/dashboard/pending-approvals/companies
const getPendingCompanies = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        const { count, rows } = await db.CompanyProfile.findAndCountAll({
            where: { status: 'pending' },
            limit: size,
            offset,
            include: [{
                model: db.User,
                as: 'user',
                attributes: ['firstName', 'lastName', 'email', 'phone']
            }]
        });

        res.status(200).json({
            success: true,
            content: rows,
            data: {
                content: rows,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get pending individual agents
// @route   GET /api/v1/admin/agents/pending-approval/individual
const getPendingAgents = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        const { count, rows } = await db.AgentProfile.findAndCountAll({
            where: {
                status: 'pending',
                agentType: 'INDIVIDUAL'
            },
            limit: size,
            offset,
            include: [{
                model: db.User,
                as: 'user',
                attributes: ['firstName', 'lastName', 'email', 'phone']
            }]
        });

        // Flatten the structure for the frontend
        const flatRows = rows.map(row => {
            const plainRow = row.get({ plain: true });
            return {
                ...plainRow,
                firstName: plainRow.user?.firstName,
                lastName: plainRow.user?.lastName,
                email: plainRow.user?.email,
                phone: plainRow.user?.phone
            };
        });

        console.log('Pending Agents Query Result:', { count, rows: rows.length });

        res.status(200).json({
            success: true,
            content: flatRows,
            data: {
                content: flatRows,
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Company
// @route   POST /api/v1/admin/companies/:id/approve
const approveCompany = async (req, res) => {
    const { id } = req.params;
    try {
        const company = await db.CompanyProfile.findByPk(id, {
            include: [{ model: db.User, as: 'user' }]
        });

        if (!company) {
            return res.status(404).json({ success: false, message: 'Company not found' });
        }

        company.status = 'approved';
        await company.save();

        if (company.user) {
            company.user.isVerified = true;
            await company.user.save();
        }

        res.status(200).json({ success: true, message: 'Company approved successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Company
// @route   POST /api/v1/admin/companies/:id/reject
const rejectCompany = async (req, res) => {
    const { id } = req.params;
    const { rejectionReason } = req.body;
    try {
        const company = await db.CompanyProfile.findByPk(id);

        if (!company) {
            return res.status(404).json({ success: false, message: 'Company not found' });
        }

        company.status = 'rejected';
        // Note: Currently no rejectionReason field in CompanyProfile schema shown earlier, 
        // if it fails, I'll allow null or just status update.
        // Checking schema: CompanyProfile.js lines 46-49 enum only.
        // Assuming validation might ignore extra fields or I strictly update status.
        await company.save();

        res.status(200).json({ success: true, message: 'Company rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Approve Agent
// @route   POST /api/v1/admin/agents/:id/approve
const approveAgent = async (req, res) => {
    const { id } = req.params;
    try {
        const agent = await db.AgentProfile.findByPk(id, {
            include: [{ model: db.User, as: 'user' }]
        });

        if (!agent) {
            return res.status(404).json({ success: false, message: 'Agent not found' });
        }

        agent.status = 'approved';
        await agent.save();

        if (agent.user) {
            agent.user.isVerified = true;
            await agent.user.save();
        }

        res.status(200).json({ success: true, message: 'Agent approved successfully' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Reject Agent
// @route   POST /api/v1/admin/agents/:id/reject
const rejectAgent = async (req, res) => {
    const { id } = req.params;
    try {
        const agent = await db.AgentProfile.findByPk(id);

        if (!agent) {
            return res.status(404).json({ success: false, message: 'Agent not found' });
        }

        agent.status = 'rejected';
        await agent.save();

        res.status(200).json({ success: true, message: 'Agent rejected' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Get pending company agents
// @route   GET /api/v1/admin/agents/pending-approval/from-company
const getPendingCompanyAgents = async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 0;
        const size = parseInt(req.query.size) || 10;
        const offset = page * size;

        // "company agents" usually means agentType='COMPANY_AGENT' or has companyId
        const { count, rows } = await db.AgentProfile.findAndCountAll({
            where: {
                status: 'pending',
                agentType: 'COMPANY_AGENT'
            },
            limit: size,
            offset,
            include: [
                {
                    model: db.User,
                    as: 'user',
                    attributes: ['firstName', 'lastName', 'email', 'phone']
                },
                {
                    model: db.CompanyProfile,
                    as: 'company',
                    attributes: ['companyName']
                }
            ]
        });

        // Flatten the structure for the frontend
        const flatRows = rows.map(row => {
            const plainRow = row.get({ plain: true });
            return {
                ...plainRow,
                firstName: plainRow.user?.firstName,
                lastName: plainRow.user?.lastName,
                email: plainRow.user?.email,
                phone: plainRow.user?.phone,
                companyName: plainRow.company?.companyName
            };
        });

        res.status(200).json({
            success: true,
            content: flatRows,
            data: {
                content: flatRows, // Frontend expects "content" or "data"
                totalPages: Math.ceil(count / size),
                totalElements: count
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

export {
    getPendingCompanies,
    getPendingAgents,
    getPendingCompanyAgents,
    approveCompany,
    rejectCompany,
    approveAgent,
    rejectAgent
};
