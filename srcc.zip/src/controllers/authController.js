import db from '../models/index.js';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { validationResult } from 'express-validator';
import sendEmail from '../services/emailService.js';
import { Op } from 'sequelize';

const generateToken = (id) => {
    return jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: '30d'
    });
};

// @desc    Auth user & get token (Login)
// @route   POST /api/v1/auth/login
const loginUser = async (req, res) => {
    const { identifier, password } = req.body;

    try {
        const user = await db.User.findOne({
            where: {
                identifier: { [Op.iLike]: identifier }
            }
        });

        if (user && (await user.matchPassword(password))) {
            // Map userType to frontend expectations
            let mappedUserType = user.userType;
            const type = user.userType.toLowerCase();

            if (type === 'company') mappedUserType = 'COMPANY_ADMIN';
            else if (type === 'admin') mappedUserType = 'ADMIN';
            else if (type === 'agent') mappedUserType = 'AGENT';
            else if (type === 'buyer') mappedUserType = 'BUYER';
            else mappedUserType = user.userType.toUpperCase();

            // Fetch Company ID if applicable
            let companyId = null;
            if (type === 'company') {
                const companyProfile = await db.CompanyProfile.findOne({ where: { userId: user.id } });
                if (companyProfile) companyId = companyProfile.id;
            } else if (type === 'company_agent') {
                // Assuming CompanyAgent model links to company
                // const agentProfile = await db.CompanyAgent.findOne({ where: { userId: user.id } });
                // if (agentProfile) companyId = agentProfile.companyId;
                // For now, if company_agent logic is not fully defined in DB models seen so far, we skip or check User model if it has companyId column (not seen in User.js). 
                // If User.js doesn't have companyId (it didn't), we rely on relationship.
                // Let's check if 'company_agent' exists in User enum. Yes.
                // Assuming CompanyAgent table exists. 
            }

            res.json({
                success: true,
                data: {
                    accessToken: generateToken(user.id),
                    user: {
                        id: user.id,
                        firstName: user.firstName,
                        lastName: user.lastName,
                        email: user.email,
                        userType: mappedUserType,
                        avatar: user.avatar,
                        companyId: companyId
                    }
                }
            });
        } else {
            res.status(401).json({ success: false, message: 'Invalid identifier or password' });
        }
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Register Buyer (Request OTP? Requirement says: Step 1 Register -> Step 2 Verify)
//          The requirement says: "Register Buyer Method: POST... Body... Verify Buyer Method: POST"
//          It seems the USER wants to Register first (Create User in DB?) then Verify.
//          Wait, typical flow is OTP first OR Register(Pending) -> OTP -> Verify(Active).
//          Let's assume Register creates user with isVerified=false and sends OTP.
// @route   POST /api/v1/auth/register
const registerBuyer = async (req, res) => {
    const { firstName, lastName, email, phone, password, userType, confirmPassword } = req.body;

    // Check pass match
    if (password !== confirmPassword) {
        return res.status(400).json({ success: false, message: 'Passwords do not match' });
    }

    try {
        const userExists = await db.User.findOne({
            where: {
                email: { [Op.iLike]: email }
            }
        });
        if (userExists) {
            return res.status(400).json({ success: false, message: 'User already exists' });
        }

        // Create Unverified User
        // Identifier is email for buyers
        const lowerCaseUserType = (userType || 'buyer').toLowerCase();

        const newUser = await db.User.create({
            identifier: email,
            email,
            firstName,
            lastName,
            phone,
            password,
            userType: lowerCaseUserType,
            isVerified: false,
            // Consents
            acceptTerms: req.body.acceptTerms,
            acceptPrivacyPolicy: req.body.acceptPrivacyPolicy,
            allowMarketingEmails: req.body.allowMarketingEmails,
            allowSmsNotifications: req.body.allowSmsNotifications,
            profileComplete: req.body.profileComplete
        });

        // Auto-create Profile based on userType
        if (lowerCaseUserType === 'company') {
            await db.CompanyProfile.create({
                userId: newUser.id,
                companyName: `${firstName} ${lastName}'s Company`, // Placeholder
                contactPersonName: `${firstName} ${lastName}`,
                status: 'pending' // Pending Admin Approval
            });
        } else if (lowerCaseUserType === 'agent') {
            await db.AgentProfile.create({
                userId: newUser.id,
                status: 'pending', // Pending Admin Approval
                agentType: 'INDIVIDUAL'
            });
        }

        // Generate OTP
        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 mins

        await db.Otp.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'registration'
        });

        // Send Email
        const message = `Your confirmation OTP is: ${otpCode}`;
        await sendEmail(email, 'Verify Registration', message, `<p>OTP: <b>${otpCode}</b></p>`);

        res.status(201).json({ success: true, message: 'User registered. Please verify OTP.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
};

// @desc    Verify Registration OTP
// @route   POST /api/v1/auth/verify-registration
const verifyBuyerRegistration = async (req, res) => {
    const { email, otpCode } = req.body;
    try {
        const otp = await db.Otp.findOne({
            where: {
                identifier: { [Op.iLike]: email },
                code: otpCode,
                isUsed: false,
                purpose: 'registration',
                expiresAt: { [Op.gt]: new Date() }
            }
        });

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        const user = await db.User.findOne({
            where: {
                email: { [Op.iLike]: email }
            }
        });
        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        // Logic Change: Only BUYER gets auto-verified. Others need Admin API.
        if (user.userType === 'buyer') {
            user.isVerified = true;
            await user.save();
        } else {
            // For Company/Agent, we just mark OTP as used (email confirmed).
            // isVerified remains false.
        }

        otp.isUsed = true;
        await otp.save();

        // Auto login token? Request implies just verification success.
        // "Login (Internal) Called automatically after verification" -> So front end calls login.
        res.json({ success: true, message: 'Registration verified.' });

    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Logout
// @route   POST /api/v1/auth/logout
const logoutUser = (req, res) => {
    res.json({ success: true, message: 'Logged out successfully' });
};

// @desc    Forgot Password (Send OTP)
// @route   POST /api/v1/auth/forgot-password
const forgotPassword = async (req, res) => {
    const { identifier } = req.body; // email via query in docs? POST body is standard. Docs say query params identifier.
    // Wait, docs say "Query Parameters: identifier". But method is POST. Using Query for POST is odd but OK.
    // Let's support both body and query for robustness.
    const email = identifier || req.query.identifier;

    try {
        const user = await db.User.findOne({
            where: {
                email: { [Op.iLike]: email }
            }
        });
        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
        const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

        await db.Otp.create({
            identifier: email,
            code: otpCode,
            expiresAt,
            purpose: 'reset_password'
        });

        await sendEmail(email, 'Reset Password OTP', `Your OTP is ${otpCode}`);

        res.json({ success: true, message: 'OTP sent for password reset.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

// @desc    Reset Password
// @route   POST /api/v1/auth/reset-password
const resetPassword = async (req, res) => {
    const { identifier, otpCode, newPassword, confirmPassword } = req.body;

    if (newPassword !== confirmPassword) return res.status(400).json({ success: false, message: 'Passwords do not match' });

    try {
        const otp = await db.Otp.findOne({
            where: {
                identifier: { [Op.iLike]: identifier },
                code: otpCode,
                isUsed: false,
                purpose: 'reset_password',
                expiresAt: { [Op.gt]: new Date() }
            }
        });

        if (!otp) return res.status(400).json({ success: false, message: 'Invalid or expired OTP' });

        const user = await db.User.findOne({
            where: {
                identifier: { [Op.iLike]: identifier }
            }
        }); // identifier is likely email
        if (!user) return res.status(404).json({ success: false, message: 'User not found' });

        user.password = newPassword; // Hook will hash it
        await user.save();

        otp.isUsed = true;
        await otp.save();

        res.json({ success: true, message: 'Password reset successfully.' });
    } catch (error) {
        res.status(500).json({ success: false, message: error.message });
    }
}

export {
    loginUser,
    registerBuyer,
    verifyBuyerRegistration,
    logoutUser,
    forgotPassword,
    resetPassword
};
