import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const Project = sequelize.define('Project', {
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true
    },
    companyId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        references: {
            model: 'CompanyProfiles',
            key: 'id'
        }
    },
    // Basic Details
    name: { type: DataTypes.STRING, allowNull: false },
    description: { type: DataTypes.TEXT, allowNull: true },
    projectType: {
        type: DataTypes.STRING, // Can be ENUM, but frontend list is long, keeping string flexibility for now
        allowNull: false
    },
    status: {
        type: DataTypes.ENUM('UPCOMING', 'UNDER_CONSTRUCTION', 'READY_TO_MOVE', 'COMPLETED'),
        defaultValue: 'UNDER_CONSTRUCTION'
    },
    approvalStatus: {
        type: DataTypes.ENUM('PENDING', 'APPROVED', 'REJECTED'),
        defaultValue: 'PENDING'
    },
    isActive: { type: DataTypes.BOOLEAN, defaultValue: true },
    isFeatured: { type: DataTypes.BOOLEAN, defaultValue: false },

    // Developer Info
    developerName: { type: DataTypes.STRING, allowNull: true },
    architectName: { type: DataTypes.STRING, allowNull: true },

    // Units & Phases
    totalPhases: { type: DataTypes.INTEGER, defaultValue: 1 },
    totalTowers: { type: DataTypes.INTEGER, defaultValue: 0 },
    totalFloors: { type: DataTypes.INTEGER, defaultValue: 0 },
    totalUnits: { type: DataTypes.INTEGER, defaultValue: 0 },
    availableUnits: { type: DataTypes.INTEGER, defaultValue: 0 },
    totalArea: { type: DataTypes.FLOAT, allowNull: true }, // Total project area

    // Pricing
    startingPrice: { type: DataTypes.DECIMAL(15, 2), allowNull: true },
    priceRangeMax: { type: DataTypes.DECIMAL(15, 2), allowNull: true },
    avgPrice: { type: DataTypes.DECIMAL(15, 2), allowNull: true },
    pricePerSqft: { type: DataTypes.DECIMAL(10, 2), allowNull: true },

    // Timeline
    launchDate: { type: DataTypes.DATEONLY, allowNull: true },
    possessionDate: { type: DataTypes.DATEONLY, allowNull: true },
    expectedCompletion: { type: DataTypes.DATEONLY, allowNull: true },

    // Location
    address: { type: DataTypes.TEXT, allowNull: true },
    city: { type: DataTypes.STRING, allowNull: true },
    state: { type: DataTypes.STRING, allowNull: true },
    pincode: { type: DataTypes.STRING, allowNull: true },
    country: { type: DataTypes.STRING, defaultValue: 'India' },
    latitude: { type: DataTypes.FLOAT, allowNull: true },
    longitude: { type: DataTypes.FLOAT, allowNull: true },
    locationAdvantages: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        defaultValue: []
    },

    // Compliance
    reraApproved: { type: DataTypes.BOOLEAN, defaultValue: false },
    reraNumber: { type: DataTypes.STRING, allowNull: true },
    reraValidityDate: { type: DataTypes.DATEONLY, allowNull: true },

    // Features & Media
    amenities: {
        type: DataTypes.ARRAY(DataTypes.STRING),
        defaultValue: []
    },
    media: {
        // Storing complex media (images, videos with types) as JSON
        // Structure: [{ type: 'IMAGE'|'VIDEO'|'brochure', url: '...', title: '...' }]
        type: DataTypes.JSONB,
        defaultValue: []
    }
}, {
    timestamps: true,
    indexes: [
        { fields: ['companyId'] },
        { fields: ['city'] },
        { fields: ['projectType'] },
        { fields: ['status'] }
    ]
});

export default Project;
