import { DataTypes } from 'sequelize';
import sequelize from '../config/database.js';

const CompanyProfile = sequelize.define('CompanyProfile', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    userId: {
        type: DataTypes.INTEGER,
        allowNull: false,
        unique: true // One user = One company profile
    },
    companyName: { type: DataTypes.STRING, allowNull: false },
    companyType: { type: DataTypes.STRING, allowNull: true },
    registrationNumber: { type: DataTypes.STRING, allowNull: true },
    establishmentYear: { type: DataTypes.INTEGER, allowNull: true },

    // Contact Person
    contactPersonName: { type: DataTypes.STRING, allowNull: true },
    contactPersonDesignation: { type: DataTypes.STRING, allowNull: true },
    alternateEmail: { type: DataTypes.STRING, allowNull: true },

    // Address
    address: { type: DataTypes.TEXT, allowNull: true },
    city: { type: DataTypes.STRING, allowNull: true },
    state: { type: DataTypes.STRING, allowNull: true },
    country: { type: DataTypes.STRING, allowNull: true },
    pincode: { type: DataTypes.STRING, allowNull: true },

    description: { type: DataTypes.TEXT, allowNull: true },
    serviceAreas: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },
    specializations: { type: DataTypes.ARRAY(DataTypes.STRING), defaultValue: [] },

    // Compliance
    gstNumber: { type: DataTypes.STRING, allowNull: true },
    panNumber: { type: DataTypes.STRING, allowNull: true },
    licenseNumber: { type: DataTypes.STRING, allowNull: true },
    licenseAuthority: { type: DataTypes.STRING, allowNull: true },
    licenseExpiryDate: { type: DataTypes.DATEONLY, allowNull: true },

    website: { type: DataTypes.STRING, allowNull: true },
    employeeCount: { type: DataTypes.INTEGER, defaultValue: 0 },

    status: {
        type: DataTypes.ENUM('pending', 'approved', 'rejected'),
        defaultValue: 'pending'
    }
}, {
    timestamps: true
});

export default CompanyProfile;
