import express from 'express';
import {
    loginUser,
    registerBuyer,
    verifyBuyerRegistration,
    logoutUser,
    forgotPassword,
    resetPassword
} from '../controllers/authController.js';
import { protect } from '../middlewares/authMiddleware.js';

const router = express.Router();

router.post('/login', loginUser);
router.post('/register', registerBuyer); // Buyer
router.post('/verify-registration', verifyBuyerRegistration);
router.post('/logout', protect, logoutUser);
router.post('/forgot-password', forgotPassword);
router.post('/reset-password', resetPassword);

export default router;
