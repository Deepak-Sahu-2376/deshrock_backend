import express from 'express';
import { getMe, uploadAvatar, deleteAvatar } from '../controllers/userController.js';
import { protect } from '../middlewares/authMiddleware.js';
import upload from '../middlewares/uploadMiddleware.js';

const router = express.Router();

router.get('/me', protect, getMe);
router.post('/me/avatar', protect, upload.single('file'), uploadAvatar);
router.delete('/me/avatar', protect, deleteAvatar);

export default router;
