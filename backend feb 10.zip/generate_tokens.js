import { OAuth2Client } from 'google-auth-library';
import http from 'http';
import url from 'url';
import open from 'open';
import destroyer from 'server-destroy';

/**
 * Configure your OAuth credentials here or load from .env
 */
import './loadEnv.js';

/**
 * Configure your OAuth credentials here or load from .env
 */
const keys = {
    client_id: process.env.YOUTUBE_CLIENT_ID,
    client_secret: process.env.YOUTUBE_CLIENT_SECRET,
    redirect_uris: [process.env.YOUTUBE_REDIRECT_URI],
};

/**
 * Start by acquiring a pre-authenticated oAuth2 client.
 */
async function main() {
    const oAuth2Client = new OAuth2Client(
        keys.client_id,
        keys.client_secret,
        keys.redirect_uris[0]
    );

    // Generate the url that will be used for the consent dialog.
    const authorizeUrl = oAuth2Client.generateAuthUrl({
        access_type: 'offline',
        scope: 'https://www.googleapis.com/auth/youtube.upload',
        prompt: 'consent' // Forces consent screen to ensure refresh token is returned
    });

    const server = http
        .createServer(async (req, res) => {
            try {
                if (req.url.indexOf('/oauth2callback') > -1) {
                    const qs = new url.URL(req.url, 'http://localhost:3000')
                        .searchParams;
                    const code = qs.get('code');
                    res.end('Authentication successful! Please return to the console.');
                    server.destroy();

                    console.log('\n--- AUTHENTICATION SUCCESSFUL ---');
                    console.log('Exchanging code for tokens...');
                    const r = await oAuth2Client.getToken({ code });
                    oAuth2Client.setCredentials(r.tokens);

                    console.log('\nHere is your REFRESH TOKEN (copy this to your .env file):');
                    console.log('----------------------------------------------------');
                    console.log(r.tokens.refresh_token);
                    console.log('----------------------------------------------------');
                }
            } catch (e) {
                console.error(e);
                res.end(e.toString());
                server.destroy();
            }
        })
        .listen(3000, () => {
            // open the browser to the authorize url to start the workflow
            open(authorizeUrl, { wait: false }).then(cp => cp.unref());
        });
    destroyer(server);
    console.log('Opening browser for authentication...');
    console.log('If it does not open automatically, please visit this URL:');
    console.log(authorizeUrl);
}

main().catch(console.error);
