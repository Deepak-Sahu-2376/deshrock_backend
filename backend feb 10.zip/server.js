import './loadEnv.js'; // Load env vars with override before other imports
import app from './src/app.js';
import db from './src/models/index.js';
import seedAdmin from './src/scripts/adminSeeder.js';
import http from 'http';
import { Server } from 'socket.io';
import jwt from 'jsonwebtoken';

const PORT = process.env.PORT || 8080;

import os from 'os';

const server = http.createServer(app);

const io = new Server(server, {
    cors: {
        origin: [
            "https://deshrock.com",
            "https://www.deshrock.com",
            "http://localhost:5173",
            "http://localhost:5173",
        ],
        methods: ["GET", "POST"],
        credentials: true
    }
});

let activeUsers = 0;

const adminSocketIds = new Set();

io.on('connection', (socket) => {
    activeUsers++;
    // console.log(`Socket connected: ${socket.id}. Active users: ${activeUsers}`);
    io.to('admin').emit('activeUsers', activeUsers);

    socket.on('disconnect', () => {
        if (adminSocketIds.has(socket.id)) {
            adminSocketIds.delete(socket.id);
            // Admin disconnected, do not decrement count as it was already excluded
            // console.log(`Admin Socket disconnected: ${socket.id}. Count remains: ${activeUsers}`);
        } else {
            activeUsers--;
            // console.log(`Socket disconnected: ${socket.id}. Active users: ${activeUsers}`);
        }
        io.to('admin').emit('activeUsers', activeUsers);
    });

    socket.on('joinAdmin', async (token) => {
        try {
            if (!token) return;
            const decoded = jwt.verify(token, process.env.JWT_SECRET);
            const user = await db.User.findByPk(decoded.id);

            if (user && (user.userType?.toUpperCase() === 'ADMIN' || user.role?.toUpperCase() === 'ADMIN')) {
                socket.join('admin');

                // If this socket wasn't already marked as admin, exclude it from count
                if (!adminSocketIds.has(socket.id)) {
                    adminSocketIds.add(socket.id);
                    activeUsers--; // Remove admin from the count
                    // console.log(`Socket ${socket.id} identified as Admin. Decrementing count to: ${activeUsers}`);
                }

                socket.emit('activeUsers', activeUsers);
                // Broadcast the updated count to other admins too
                io.to('admin').emit('activeUsers', activeUsers);
            }
        } catch (error) {
            // console.error(`Socket authentication failed for ${socket.id}:`, error.message);
        }
    });
});

const startServer = async () => {
    try {
        await db.sequelize.authenticate();
        console.log('Database connected successfully.');

        // Sync models
        await db.sequelize.sync({ alter: true });
        console.log('Database synced.');

        // Run Seeder
        await seedAdmin(); // Create Admin

        const networkInterfaces = os.networkInterfaces();
        let ipAddress = 'localhost';

        Object.keys(networkInterfaces).forEach((interfaceName) => {
            networkInterfaces[interfaceName].forEach((iface) => {
                if (iface.family === 'IPv4' && !iface.internal) {
                    ipAddress = iface.address;
                }
            });
        });

        server.listen(PORT, '0.0.0.0', async () => {
            console.log(`Server is running on:`);
            console.log(`- Local:   http://localhost:${PORT}`);
            console.log(`- Network: http://${ipAddress}:${PORT}`);

            try {
                const response = await fetch('http://checkip.amazonaws.com');
                if (response.ok) {
                    const publicIp = (await response.text()).trim();
                    console.log(`- Public:  http://${publicIp}:${PORT}`);
                }
            } catch (error) {
                // IP fetch failed, fail silently or log debug
                // console.debug('Could not fetch public IP');
            }
        });

    } catch (error) {
        console.error('Unable to start server:', error);
    }
};

startServer();
